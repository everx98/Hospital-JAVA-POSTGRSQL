/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import Datos.Paciente;
import Datos.Receta;
import Datos.Usuario;
import Datos.Session;
import java.awt.BorderLayout;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author PC
 */
public class Upaciente extends javax.swing.JPanel {

   private EntityManagerFactory emf;
    private EntityManager em;
    private EntityManager entityManager;
   
  
    
    
    public Upaciente() {
         setLayout(new BorderLayout());
        initComponents();
        emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();
        cargarDatos();
        this.entityManager = emf.createEntityManager();
         setVisible(true);
    }    
     
   
   private void cargarDatos() {
       
       
       Usuario usuarioActual = obtenerUsuarioActual();

    if (usuarioActual != null) {
        cargarDatosPaciente(usuarioActual.getNombre());
    } else {
        JOptionPane.showMessageDialog(this, "Error: No hay un usuario autenticado.");
    }
}

private Usuario obtenerUsuarioActual() {
    Usuario usuario = Session.getCurrentUser();
    if (usuario != null) {
        System.out.println("Usuario actual: " + usuario.getNombre());
    } else {
        System.out.println("No hay usuario autenticado.");
    }
    return usuario;
}

private void cargarDatosPaciente(String nombreUsuario) {
    EntityManager em = emf.createEntityManager();
    try {
        String jpql = "SELECT p FROM Paciente p WHERE p.nombreCompleto = :nombreCompleto";
        Paciente paciente = em.createQuery(jpql, Paciente.class)
                              .setParameter("nombreCompleto", nombreUsuario)
                              .getSingleResult();

        if (paciente != null) {
            mostrarDatosPaciente(paciente);
            cargarDatosReceta(paciente.getId()); 
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró un paciente con ese nombre.");
        }
    } catch (NoResultException e) {
        JOptionPane.showMessageDialog(this, "No se encontró un paciente con ese nombre.");
    } catch (Exception e) {
        e.printStackTrace(); 
        JOptionPane.showMessageDialog(this, "Error al cargar los datos del paciente.");
    } finally {
        em.close();
    }
}

private void mostrarDatosPaciente(Paciente paciente) {
    txtNombreC.setText(paciente.getNombreCompleto());
    txtDireccion.setText(paciente.getDireccion());
    txtHistorial.setText(paciente.getHistorialMedico());
    txtCurp.setText(paciente.getNumeroIdentificacion());
    txtCorreoEle.setText(paciente.getCorreoElectronico());
    txtTelefono.setText(paciente.getTelefono());
    txtGrupoSanguineo.setText(paciente.getGrupoSanguineo());
    txtAlergias.setText(paciente.getAlergias());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fechaNacimientoFormateada = dateFormat.format(paciente.getFechaNacimiento());
        txtFechaNaci.setText(fechaNacimientoFormateada); 
    txtNacionalidad.setText(paciente.getNacionalidad());
    txtIdU.setText(String.valueOf(paciente.getId()));
    txtPeso.setText(String.valueOf(paciente.getPeso()));
    txtEstatura.setText(String.valueOf(paciente.getEstatura()));
    
    if ("Masculino".equals(paciente.getSexo())) {
        jMasculino.setSelected(true);
    } else {
        jFemenino.setSelected(true);
    }
}

private void cargarDatosReceta(Long pacienteId) {
    EntityManager em = emf.createEntityManager();
    try {
        String jpql = "SELECT r FROM Receta r WHERE r.paciente.id = :pacienteId";
        List<Receta> recetas = em.createQuery(jpql, Receta.class)
                                  .setParameter("pacienteId", pacienteId)
                                  .getResultList();

        if (!recetas.isEmpty()) {
            Receta receta = recetas.get(0); 
            mostrarDatosReceta(receta);
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró una receta para el paciente.");
        }
    } catch (Exception e) {
        e.printStackTrace(); 
        JOptionPane.showMessageDialog(this, "Error al cargar los datos de la receta.");
    } finally {
        em.close();
    }
}

private void mostrarDatosReceta(Receta receta) { 
      
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String fechaEmisionFormateada = dateFormat.format(receta.getFechaEmision());
        txtFechaEmicion.setText(fechaEmisionFormateada); 
        txtNumReceta.setText(String.valueOf(receta.getId()));
        txtIdMedico.setText(String.valueOf(receta.getMedico().getId())); 
        txtMediPres.setText(receta.getMedicamentosPrescritos());
        txtInstrucciones.setText(receta.getInstruccionesAdicionales());
    }

     
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtTelefono = new javax.swing.JTextField();
        txtMediPres = new javax.swing.JTextField();
        jlCorreoE = new javax.swing.JLabel();
        txtFechaEmicion = new javax.swing.JTextField();
        txtCorreoEle = new javax.swing.JTextField();
        jlMediPresc = new javax.swing.JLabel();
        jlAlergias = new javax.swing.JLabel();
        jlInstrucciones = new javax.swing.JLabel();
        jlHistorial = new javax.swing.JLabel();
        txtInstrucciones = new javax.swing.JTextField();
        jlRECETA = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAlergias = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtHistorial = new javax.swing.JTextArea();
        txtIdU = new javax.swing.JTextField();
        txtNombreC = new javax.swing.JTextField();
        btmSalir = new javax.swing.JButton();
        txtFechaNaci = new javax.swing.JTextField();
        jMasculino = new javax.swing.JRadioButton();
        jlGrupoSnaguineo = new javax.swing.JLabel();
        jFemenino = new javax.swing.JRadioButton();
        txtGrupoSanguineo = new javax.swing.JTextField();
        jlNacionalidad = new javax.swing.JLabel();
        jlCurp = new javax.swing.JLabel();
        jlDireccion = new javax.swing.JLabel();
        jlNumReceta = new javax.swing.JLabel();
        txtNacionalidad = new javax.swing.JTextField();
        txtCurp = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jlId = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jlFechaNacimiento = new javax.swing.JLabel();
        jlSexo = new javax.swing.JLabel();
        txtNumReceta = new javax.swing.JTextField();
        jlIdMedico = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        txtIdMedico = new javax.swing.JTextField();
        jlTelefono = new javax.swing.JLabel();
        jlFechaEmision = new javax.swing.JLabel();
        jlPeso = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        jlEstatura = new javax.swing.JLabel();
        txtEstatura = new javax.swing.JTextField();
        btmCita = new javax.swing.JButton();

        txtMediPres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMediPresActionPerformed(evt);
            }
        });

        jlCorreoE.setText("Correo Electronico:");

        jlMediPresc.setText("Medicamentos Prescritos:");

        jlAlergias.setText("Alergias:");

        jlInstrucciones.setText("Instrucciones Adicionales:");

        jlHistorial.setText("Historial medico:");

        jlRECETA.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jlRECETA.setText("Receta:");

        txtAlergias.setColumns(20);
        txtAlergias.setRows(5);
        jScrollPane2.setViewportView(txtAlergias);

        txtHistorial.setColumns(20);
        txtHistorial.setRows(5);
        jScrollPane3.setViewportView(txtHistorial);

        txtIdU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdUActionPerformed(evt);
            }
        });

        btmSalir.setText("Salir");
        btmSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmSalirActionPerformed(evt);
            }
        });

        jMasculino.setText("M");
        jMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMasculinoActionPerformed(evt);
            }
        });

        jlGrupoSnaguineo.setText("Grupo sanguineo:");

        jFemenino.setText("F");
        jFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFemeninoActionPerformed(evt);
            }
        });

        jlNacionalidad.setText("Nacionalidad:");

        jlCurp.setText("CURP:");

        jlDireccion.setText("Dirección:");

        jlNumReceta.setText("Receta numero:");

        jPanel2.setBackground(new java.awt.Color(0, 204, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1092, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 42, Short.MAX_VALUE)
        );

        jlId.setText("Id del paciente:");

        jLabel2.setText("Nombre completo:");

        jlFechaNacimiento.setText("Fecha de nacimiento:");

        jlSexo.setText("Sexo:");

        jlIdMedico.setText("Id medico:");

        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });

        jlTelefono.setText("Telefono:");

        jlFechaEmision.setText("Fecha de emision:");

        jlPeso.setText("Peso:");

        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        jlEstatura.setText("Estatura:");

        btmCita.setText("Agendar Cita");
        btmCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmCitaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(134, 134, 134)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jlPeso)
                            .addGap(37, 37, 37)
                            .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jlEstatura)
                            .addGap(39, 39, 39)
                            .addComponent(txtEstatura, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btmCita, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btmSalir, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlIdMedico, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jlNumReceta, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jlFechaEmision))
                            .addComponent(jlMediPresc, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jlInstrucciones, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtFechaEmicion)
                            .addComponent(txtMediPres)
                            .addComponent(txtIdMedico)
                            .addComponent(txtNumReceta)
                            .addComponent(txtInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlRECETA, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jlCorreoE)
                                    .addComponent(jlTelefono)
                                    .addComponent(jlAlergias)
                                    .addComponent(jlHistorial))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCorreoEle, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(86, 86, 86))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(61, 61, 61)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addComponent(jlId)
                                .addComponent(jlFechaNacimiento)
                                .addComponent(jlSexo)
                                .addComponent(jlNacionalidad)
                                .addComponent(jlCurp)
                                .addComponent(jlDireccion)
                                .addComponent(jlGrupoSnaguineo))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(59, 59, 59)
                                    .addComponent(jMasculino)
                                    .addGap(43, 43, 43)
                                    .addComponent(jFemenino))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(46, 46, 46)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtGrupoSanguineo, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                                        .addComponent(txtIdU)
                                        .addComponent(txtNombreC)
                                        .addComponent(txtFechaNaci)
                                        .addComponent(txtNacionalidad)
                                        .addComponent(txtCurp)
                                        .addComponent(txtDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)))))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(27, 27, 27)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(482, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlPeso)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlEstatura)
                    .addComponent(txtEstatura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addComponent(btmSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btmCita, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(276, 276, 276))
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlTelefono)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlCorreoE)
                    .addComponent(txtCorreoEle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jlAlergias)
                        .addGap(45, 45, 45))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(85, 85, 85))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(jlHistorial)
                        .addGap(87, 87, 87)
                        .addComponent(jlRECETA, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlNumReceta)
                            .addComponent(txtNumReceta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlIdMedico)
                            .addComponent(txtIdMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlFechaEmision)
                            .addComponent(txtFechaEmicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMediPres, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlMediPresc))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlInstrucciones))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(69, 69, 69)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jlId)
                        .addComponent(txtIdU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(30, 30, 30)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(txtNombreC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(28, 28, 28)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jlFechaNacimiento)
                        .addComponent(txtFechaNaci, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(24, 24, 24)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jlSexo)
                        .addComponent(jMasculino)
                        .addComponent(jFemenino))
                    .addGap(43, 43, 43)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(149, 149, 149)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtGrupoSanguineo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jlGrupoSnaguineo)))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlNacionalidad)
                                .addComponent(txtNacionalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(30, 30, 30)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlCurp)
                                .addComponent(txtCurp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(25, 25, 25)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jlDireccion)
                                .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 466, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtMediPresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMediPresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMediPresActionPerformed

    private void btmSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btmSalirActionPerformed

    private void jMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMasculinoActionPerformed

    private void jFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFemeninoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFemeninoActionPerformed

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed

    }//GEN-LAST:event_txtDireccionActionPerformed

    private void txtIdUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdUActionPerformed

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void btmCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmCitaActionPerformed
        CitasU citas = new CitasU();
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
    frame.setContentPane(citas);
    frame.revalidate(); 
    frame.repaint(); 
    }//GEN-LAST:event_btmCitaActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmCita;
    private javax.swing.JButton btmSalir;
    private javax.swing.JRadioButton jFemenino;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JRadioButton jMasculino;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel jlAlergias;
    private javax.swing.JLabel jlCorreoE;
    private javax.swing.JLabel jlCurp;
    private javax.swing.JLabel jlDireccion;
    private javax.swing.JLabel jlEstatura;
    private javax.swing.JLabel jlFechaEmision;
    private javax.swing.JLabel jlFechaNacimiento;
    private javax.swing.JLabel jlGrupoSnaguineo;
    private javax.swing.JLabel jlHistorial;
    private javax.swing.JLabel jlId;
    private javax.swing.JLabel jlIdMedico;
    private javax.swing.JLabel jlInstrucciones;
    private javax.swing.JLabel jlMediPresc;
    private javax.swing.JLabel jlNacionalidad;
    private javax.swing.JLabel jlNumReceta;
    private javax.swing.JLabel jlPeso;
    private javax.swing.JLabel jlRECETA;
    private javax.swing.JLabel jlSexo;
    private javax.swing.JLabel jlTelefono;
    private javax.swing.JTextArea txtAlergias;
    private javax.swing.JTextField txtCorreoEle;
    private javax.swing.JTextField txtCurp;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEstatura;
    private javax.swing.JTextField txtFechaEmicion;
    private javax.swing.JTextField txtFechaNaci;
    private javax.swing.JTextField txtGrupoSanguineo;
    private javax.swing.JTextArea txtHistorial;
    private javax.swing.JTextField txtIdMedico;
    private javax.swing.JTextField txtIdU;
    private javax.swing.JTextField txtInstrucciones;
    private javax.swing.JTextField txtMediPres;
    private javax.swing.JTextField txtNacionalidad;
    private javax.swing.JTextField txtNombreC;
    private javax.swing.JTextField txtNumReceta;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
