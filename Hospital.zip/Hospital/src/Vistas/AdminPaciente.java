/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import Datos.Medico;
import Datos.Paciente;
import Datos.Receta;
import Datos.Session;
import Datos.Usuario;
import java.awt.event.AdjustmentEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;



public class AdminPaciente extends javax.swing.JPanel {
    private EntityManagerFactory emf;
    private EntityManager em;
    private ArrayList<Paciente> pacientes = new ArrayList<>();
    private DefaultTableModel tableModel;
    @PersistenceContext
    private EntityManager entityManager;

    
    public AdminPaciente() {
        emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();
        this.entityManager = emf.createEntityManager();
        initComponents();
        this.entityManager = emf.createEntityManager(); 
        loadPatients();
         updatePatientTable();
         cargarDatos();
        
    }
    //metodo para cargar el id del medico en el campo de la receta 
  private void cargarDatos() {
        
        Usuario usuarioActual = obtenerUsuarioActual();

        if (usuarioActual != null) {
            cargarDatosMedico(usuarioActual.getNombre());
        } else {
            JOptionPane.showMessageDialog(this, "Error: No hay un usuario autenticado.");
        }
    }

    private Usuario obtenerUsuarioActual() {
      
        Usuario usuario = Session.getCurrentUser();
        if (usuario != null) {
            System.out.println("Usuario actual: " + usuario.getNombre());
        } else {
            System.out.println("No hay usuario autenticado.");
        }
        return usuario;
    }

    private void cargarDatosMedico(String nombreUsuario) {
        EntityManager em = emf.createEntityManager();
        try {
            
            String jpql = "SELECT m FROM Medico m WHERE m.nombreCompleto = :nombreCompleto";
            Medico medico = em.createQuery(jpql, Medico.class)
                                  .setParameter("nombreCompleto", nombreUsuario)
                                  .getSingleResult();

            if (medico != null) {
                
                mostrarDatosMedico(medico);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un medico con ese nombre.");
            }
        } catch (NoResultException e) {
            JOptionPane.showMessageDialog(this, "No se encontró un medico con ese nombre.");
        } catch (Exception e) {
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Error al cargar los datos del medico.");
        } finally {
            em.close();
        }
    }
    private void mostrarDatosMedico(Medico medico) {
        
        txtIdMedico.setText(String.valueOf(medico.getId()));
        
    }
    
  
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jlId = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jlFechaNacimiento = new javax.swing.JLabel();
        jlSexo = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btmBuscar = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        txtNombreC = new javax.swing.JTextField();
        txtFechaNaci = new javax.swing.JTextField();
        jMasculino = new javax.swing.JRadioButton();
        jFemenino = new javax.swing.JRadioButton();
        jlNacionalidad = new javax.swing.JLabel();
        jlCurp = new javax.swing.JLabel();
        jlDireccion = new javax.swing.JLabel();
        txtNacionalidad = new javax.swing.JTextField();
        txtCurp = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        jlTelefono = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jlCorreoE = new javax.swing.JLabel();
        txtCorreoEle = new javax.swing.JTextField();
        jlAlergias = new javax.swing.JLabel();
        jlHistorial = new javax.swing.JLabel();
        jlRECETA = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAlergias = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtHistorial = new javax.swing.JTextArea();
        btmGuardar = new javax.swing.JButton();
        btmSalir = new javax.swing.JButton();
        btmNuevo = new javax.swing.JButton();
        jlGrupoSnaguineo = new javax.swing.JLabel();
        txtGrupoSanguineo = new javax.swing.JTextField();
        btmModificar = new javax.swing.JButton();
        btmEliminar = new javax.swing.JButton();
        jlNumReceta = new javax.swing.JLabel();
        txtNumReceta = new javax.swing.JTextField();
        jlIdMedico = new javax.swing.JLabel();
        txtIdMedico = new javax.swing.JTextField();
        jlFechaEmision = new javax.swing.JLabel();
        txtMediPres = new javax.swing.JTextField();
        txtFechaEmicion = new javax.swing.JTextField();
        jlMediPresc = new javax.swing.JLabel();
        jlInstrucciones = new javax.swing.JLabel();
        txtInstrucciones = new javax.swing.JTextField();
        btmMedico = new javax.swing.JToggleButton();
        jlPeso = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtEstatura = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btmCitas = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel2.setBackground(new java.awt.Color(0, 204, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1092, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 42, Short.MAX_VALUE)
        );

        jlId.setText("Id del paciente:");

        jLabel2.setText("Nombre completo:");

        jlFechaNacimiento.setText("Fecha de nacimiento:");

        jlSexo.setText("Sexo:");

        btmBuscar.setText("Buscar");
        btmBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmBuscarActionPerformed(evt);
            }
        });

        jMasculino.setText("M");
        jMasculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMasculinoActionPerformed(evt);
            }
        });

        jFemenino.setText("F");
        jFemenino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFemeninoActionPerformed(evt);
            }
        });

        jlNacionalidad.setText("Nacionalidad:");

        jlCurp.setText("CURP:");

        jlDireccion.setText("Dirección:");

        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });

        jlTelefono.setText("Telefono:");

        jlCorreoE.setText("Correo Electronico:");

        jlAlergias.setText("Alergias:");

        jlHistorial.setText("Historial medico:");

        jlRECETA.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jlRECETA.setText("Receta:");

        txtAlergias.setColumns(20);
        txtAlergias.setRows(5);
        jScrollPane2.setViewportView(txtAlergias);

        txtHistorial.setColumns(20);
        txtHistorial.setRows(5);
        jScrollPane3.setViewportView(txtHistorial);

        btmGuardar.setText("Guardar");
        btmGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmGuardarActionPerformed(evt);
            }
        });

        btmSalir.setText("Salir");
        btmSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmSalirActionPerformed(evt);
            }
        });

        btmNuevo.setText("Nuevo");
        btmNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmNuevoActionPerformed(evt);
            }
        });

        jlGrupoSnaguineo.setText("Grupo sanguineo:");

        btmModificar.setText("Modificar");
        btmModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmModificarActionPerformed(evt);
            }
        });

        btmEliminar.setText("Eliminar");
        btmEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmEliminarActionPerformed(evt);
            }
        });

        jlNumReceta.setText("Receta numero:");

        jlIdMedico.setText("Id medico:");

        jlFechaEmision.setText("Fecha de emision:");

        txtMediPres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMediPresActionPerformed(evt);
            }
        });

        jlMediPresc.setText("Medicamentos Prescritos:");

        jlInstrucciones.setText("Instrucciones Adicionales:");

        btmMedico.setText("Medico datos:");
        btmMedico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmMedicoActionPerformed(evt);
            }
        });

        jlPeso.setText("Peso:");

        jLabel1.setText("Estatura:");

        jLabel3.setText("(el numero se genera de manera automatica)");

        btmCitas.setText("Citas");
        btmCitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmCitasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(40, 40, 40)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btmGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(btmNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btmSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(50, 50, 50)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(btmModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btmEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                                        .addComponent(btmCitas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel2)
                                        .addComponent(jlId)
                                        .addComponent(jlFechaNacimiento)
                                        .addComponent(jlSexo)
                                        .addComponent(jlNacionalidad)
                                        .addComponent(jlCurp)
                                        .addComponent(jlDireccion)
                                        .addComponent(jlGrupoSnaguineo)
                                        .addComponent(jlPeso)
                                        .addComponent(jLabel1))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(59, 59, 59)
                                            .addComponent(jMasculino)
                                            .addGap(43, 43, 43)
                                            .addComponent(jFemenino))
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(46, 46, 46)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(txtPeso)
                                                .addComponent(txtGrupoSanguineo, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                                                .addComponent(txtId)
                                                .addComponent(txtNombreC)
                                                .addComponent(txtFechaNaci)
                                                .addComponent(txtNacionalidad)
                                                .addComponent(txtCurp)
                                                .addComponent(txtDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                                                .addComponent(txtEstatura))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(54, 54, 54)
                                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(jlIdMedico, javax.swing.GroupLayout.Alignment.TRAILING)
                                                                .addComponent(jlNumReceta, javax.swing.GroupLayout.Alignment.TRAILING)))
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGap(42, 42, 42)
                                                            .addComponent(jlFechaEmision))
                                                        .addComponent(jlMediPresc, javax.swing.GroupLayout.Alignment.TRAILING)
                                                        .addComponent(jlInstrucciones, javax.swing.GroupLayout.Alignment.TRAILING))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                            .addComponent(txtFechaEmicion, javax.swing.GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
                                                            .addComponent(txtMediPres)
                                                            .addComponent(txtIdMedico)
                                                            .addComponent(txtInstrucciones))
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addComponent(txtNumReceta, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(138, 138, 138)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jlRECETA, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                                .addComponent(jlCorreoE)
                                                                .addComponent(jlTelefono)
                                                                .addComponent(jlAlergias)
                                                                .addComponent(jlHistorial))
                                                            .addGap(18, 18, 18)
                                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                                .addComponent(txtCorreoEle, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))))))))))
                            .addGap(62, 62, 62)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 311, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(btmBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btmMedico)
                        .addGap(153, 153, 153)))
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(952, 952, 952)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btmBuscar)
                            .addComponent(btmMedico))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlId)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlTelefono)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtNombreC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlCorreoE)
                            .addComponent(txtCorreoEle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jlFechaNacimiento)
                                    .addComponent(txtFechaNaci, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jlAlergias))
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jlSexo)
                                    .addComponent(jMasculino)
                                    .addComponent(jFemenino)))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtGrupoSanguineo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jlGrupoSnaguineo)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jlNacionalidad)
                                    .addComponent(txtNacionalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jlHistorial))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(87, 87, 87)
                                        .addComponent(jlRECETA, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(35, 35, 35)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jlNumReceta)
                                            .addComponent(txtNumReceta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel3))
                                        .addGap(40, 40, 40)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jlIdMedico)
                                            .addComponent(txtIdMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(37, 37, 37)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jlFechaEmision)
                                            .addComponent(txtFechaEmicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jlCurp)
                                            .addComponent(txtCurp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(25, 25, 25)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jlDireccion)
                                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(92, 92, 92)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jlPeso)
                                            .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(26, 26, 26)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel1)
                                            .addComponent(txtEstatura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(35, 35, 35)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(btmGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btmModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(16, 16, 16)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(btmEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btmNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(btmSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btmCitas, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(txtMediPres, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jlMediPresc))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(txtInstrucciones, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jlInstrucciones))))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(89, 89, 89)))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btmGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmGuardarActionPerformed

Paciente paciente = new Paciente();
Receta receta = new Receta();

// Validación para asegurar que ningún campo esté vacío
if (txtId.getText().isEmpty() || txtNombreC.getText().isEmpty() || txtCurp.getText().isEmpty() || 
    txtDireccion.getText().isEmpty() || txtTelefono.getText().isEmpty() || txtCorreoEle.getText().isEmpty() || 
    txtNacionalidad.getText().isEmpty() || txtHistorial.getText().isEmpty() || txtGrupoSanguineo.getText().isEmpty() || 
    (!jMasculino.isSelected() && !jFemenino.isSelected()) || txtAlergias.getText().isEmpty() || 
    txtPeso.getText().isEmpty() || txtEstatura.getText().isEmpty() || txtFechaNaci.getText().isEmpty() || 
    txtInstrucciones.getText().isEmpty() || txtMediPres.getText().isEmpty() || txtFechaEmicion.getText().isEmpty() || 
    txtIdMedico.getText().isEmpty()) {
    
    JOptionPane.showMessageDialog(null, "Error: Todos los campos deben estar llenos.");
    return;
}

// Validación de ID del Paciente (solo números)
try {
    Long idPaciente = Long.parseLong(txtId.getText());
    paciente.setId(idPaciente);
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Error: El ID del paciente solo debe contener números.");
    return;
}

if (txtId.getText().length() != 10) {
    JOptionPane.showMessageDialog(null, "Error: El número de id debe ser de 10 caracteres");
    return;
}

// Validación de nombre completo (sin números ni caracteres especiales)
if (!txtNombreC.getText().matches("[a-zA-Z\\s]+")) {
    JOptionPane.showMessageDialog(null, "Error: El nombre completo solo debe contener letras.");
    return;
}
paciente.setNombreCompleto(txtNombreC.getText());

// Validación de número de identificación (exactamente 18 caracteres)
if (txtCurp.getText().length() != 18) {
    JOptionPane.showMessageDialog(null, "Error: El número de identificación debe tener exactamente 18 caracteres.");
    return;
}
paciente.setNumeroIdentificacion(txtCurp.getText());

// Validación de dirección (puede aceptar cualquier texto)
paciente.setDireccion(txtDireccion.getText());

// Validación de teléfono (solo números, exactamente 10 dígitos)
if (!txtTelefono.getText().matches("\\d{10}")) {
    JOptionPane.showMessageDialog(null, "Error: El teléfono debe contener exactamente 10 dígitos.");
    return;
}
paciente.setTelefono(txtTelefono.getText());

// Validación de correo electrónico (formato válido)
if (!txtCorreoEle.getText().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
    JOptionPane.showMessageDialog(null, "Error: Formato de correo electrónico inválido.");
    return;
}
paciente.setCorreoElectronico(txtCorreoEle.getText());

// Validación de nacionalidad (sin validación especial)
paciente.setNacionalidad(txtNacionalidad.getText());

// Validación de historial médico (sin validación especial)
paciente.setHistorialMedico(txtHistorial.getText());

// Validación de grupo sanguíneo (solo valores permitidos)
if (!txtGrupoSanguineo.getText().matches("^(A|B|AB|O)[+-]$")) {
    JOptionPane.showMessageDialog(null, "Error: Grupo sanguíneo inválido. Use AB, A, B, O, + o -.");
    return;
}
paciente.setGrupoSanguineo(txtGrupoSanguineo.getText());

// Validación de sexo (debe seleccionar Masculino o Femenino)
if (!jMasculino.isSelected() && !jFemenino.isSelected()) {
    JOptionPane.showMessageDialog(null, "Error: Debe seleccionar el sexo del paciente.");
    return;
} else {
    paciente.setSexo(jMasculino.isSelected() ? "Masculino" : "Femenino");
}

// Validación de alergias (sin validación especial)
paciente.setAlergias(txtAlergias.getText());

// Validación de peso (solo números)
try {
    Integer peso = Integer.parseInt(txtPeso.getText());
    paciente.setPeso(peso);
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Error: El peso solo debe contener números.");
    return;
}

// Validación de estatura (solo números)
try {
    Long estatura = Long.parseLong(txtEstatura.getText());
    paciente.setEstatura(estatura);
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Error: La estatura solo debe contener números.");
    return;
}

// Validación de fecha de nacimiento (formato correcto y valores de día/mes válidos)
try {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false); // Evita aceptar fechas inválidas
    java.util.Date fechaUtil = sdf.parse(txtFechaNaci.getText().trim());

    // Validar días y meses
    String[] partesFecha = txtFechaNaci.getText().split("-");
    int anio = Integer.parseInt(partesFecha[0]);
    int mes = Integer.parseInt(partesFecha[1]);
    int dia = Integer.parseInt(partesFecha[2]);

    // Validar días del mes de febrero (incluyendo si es bisiesto)
    if (mes == 2 && ((dia > 29) || (dia == 29 && !esAnioBisiesto(anio)))) {
        JOptionPane.showMessageDialog(null, "Error: Febrero no puede tener más de 29 días, a menos que el año sea bisiesto.");
        return;
    }

    // Validar días para meses que no tienen más de 31 días
    if ((mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia > 30) {
        JOptionPane.showMessageDialog(null, "Error: Este mes no puede tener más de 30 días.");
        return;
    } else if (dia > 31) {
        JOptionPane.showMessageDialog(null, "Error: Un mes no puede tener más de 31 días.");
        return;
    }

    java.sql.Date fechaNacimiento = new java.sql.Date(fechaUtil.getTime());
    paciente.setFechaNacimiento(fechaNacimiento);
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: Formato de fecha de nacimiento inválido. Use 'yyyy-MM-dd'.");
    return;
}

// Validación de fecha de emisión de receta (formato correcto)
try {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false); // Asegura que no se acepten fechas inválidas
    java.util.Date utilDate = sdf.parse(txtFechaEmicion.getText().trim());
    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
    receta.setFechaEmision(sqlDate);
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error: Formato de fecha de emisión inválido. Use 'yyyy-MM-dd'.");
    return;
}
receta.setInstruccionesAdicionales(txtInstrucciones.getText());
receta.setMedicamentosPrescritos(txtMediPres.getText());
// Validación del ID del médico (solo números)
try {
    Long idMedico = Long.parseLong(txtIdMedico.getText());
    Medico medico = em.find(Medico.class, idMedico);

    if (medico != null) {
        receta.setMedico(medico);
    } else {
        JOptionPane.showMessageDialog(null, "Error: No se encontró un médico con ese ID.");
        return;
    }
} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Error: El ID del médico solo debe contener números.");
    return;
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error al buscar el médico: " + e.getMessage());
    return;
}

// Comprobar si ya existe un paciente con el mismo número de identificación
TypedQuery<Paciente> query = em.createQuery("SELECT p FROM Paciente p WHERE p.numeroIdentificacion = :numeroIdentificacion", Paciente.class);
query.setParameter("numeroIdentificacion", paciente.getNumeroIdentificacion());

if (!query.getResultList().isEmpty()) {
    JOptionPane.showMessageDialog(null, "Error: Ya existe un paciente con ese número de identificación.");
    return;
}

// Guardar paciente y receta
try { 
    em.getTransaction().begin();
    em.persist(paciente);
    receta.setPaciente(paciente);
    em.persist(receta);
    em.getTransaction().commit();
    JOptionPane.showMessageDialog(null, "El paciente y la receta han sido guardados exitosamente.");
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, "Error al guardar el paciente o la receta: " + e.getMessage());
    if (em.getTransaction().isActive()) {
        em.getTransaction().rollback();
    }
}




  
    }//GEN-LAST:event_btmGuardarActionPerformed

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
      
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void jMasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMasculinoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMasculinoActionPerformed

    private void jFemeninoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFemeninoActionPerformed
       
    }//GEN-LAST:event_jFemeninoActionPerformed

    private void btmBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmBuscarActionPerformed
  
     String nombreText = txtBuscar.getText().trim(); 
    if (!nombreText.isEmpty()) {     
        TypedQuery<Paciente> query = em.createQuery("SELECT p FROM Paciente p WHERE p.nombreCompleto LIKE :nombreCompleto", Paciente.class);
        query.setParameter("nombreCompleto", "%" + nombreText + "%"); 
        List<Paciente> pacientes = query.getResultList();
        if (!pacientes.isEmpty()) {
            for (Paciente p : pacientes) {
             
                populateFields(p);

                
                TypedQuery<Receta> recetaQuery = em.createQuery("SELECT r FROM Receta r WHERE r.paciente.id = :pacienteId", Receta.class);
                recetaQuery.setParameter("pacienteId", p.getId());

              
                clearRecetaFields();  

                List<Receta> recetas = recetaQuery.getResultList();

                if (!recetas.isEmpty()) {
                    for (Receta receta : recetas) {
                        
                        populateRecetaFields(receta);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Este paciente no tiene recetas asociadas.");
                }

                JOptionPane.showMessageDialog(null, "Paciente encontrado por nombre: " + p.getNombreCompleto());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error: No se encontró ningún paciente con ese nombre.");
        }
    } else {
        JOptionPane.showMessageDialog(null, "Error: Debe ingresar un ID o un nombre para buscar.");
    }

    }
   private void populateFields(Paciente paciente) {
    
    txtId.setText(String.valueOf(paciente.getId()));
    txtNombreC.setText(paciente.getNombreCompleto());
    txtCurp.setText(paciente.getNumeroIdentificacion());
    txtDireccion.setText(paciente.getDireccion());
    txtTelefono.setText(paciente.getTelefono());
    txtCorreoEle.setText(paciente.getCorreoElectronico());
    txtNacionalidad.setText(paciente.getNacionalidad());
    txtHistorial.setText(paciente.getHistorialMedico());
    txtGrupoSanguineo.setText(paciente.getGrupoSanguineo());
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String fechaFormateada = sdf.format(paciente.getFechaNacimiento());
    txtFechaNaci.setText(fechaFormateada);
    txtAlergias.setText(paciente.getAlergias());
    txtPeso.setText(String.valueOf(paciente.getPeso()));
    txtEstatura.setText(String.valueOf(paciente.getEstatura()));

    if ("Masculino".equals(paciente.getSexo())) {
        jMasculino.setSelected(true);
    } else {
        jFemenino.setSelected(true);
    }


}
    private void populateRecetaFields(Receta receta) {

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String fechaEmision = sdf.format(receta.getFechaEmision());
    txtFechaEmicion.setText(fechaEmision);
     txtNumReceta.setText(String.valueOf(receta.getId()));

   
    if (receta.getMedico() != null) {
        txtIdMedico.setText(String.valueOf(receta.getMedico().getId())); 
    } else {
        txtIdMedico.setText(""); 
    }
    
    txtMediPres.setText(receta.getMedicamentosPrescritos());
    txtInstrucciones.setText(receta.getInstruccionesAdicionales());




   
    }//GEN-LAST:event_btmBuscarActionPerformed

    private void btmSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmSalirActionPerformed
        System.exit(0); 
    }//GEN-LAST:event_btmSalirActionPerformed

    private void btmNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmNuevoActionPerformed
        clearFields();
        txtId.setText("");
        txtGrupoSanguineo.setText("");
        txtNumReceta.setText("");
        txtFechaEmicion.setText("");
        txtMediPres.setText("");
        txtInstrucciones.setText("");
        txtPeso.setText("");
        txtEstatura.setText("");
    }//GEN-LAST:event_btmNuevoActionPerformed

    private void btmModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmModificarActionPerformed
 
    if (txtId.getText().trim().isEmpty() || txtNumReceta.getText().trim().isEmpty() ||
        txtNombreC.getText().trim().isEmpty() || txtCurp.getText().trim().isEmpty() ||
        txtDireccion.getText().trim().isEmpty() || txtTelefono.getText().trim().isEmpty() ||
        txtCorreoEle.getText().trim().isEmpty() || txtNacionalidad.getText().trim().isEmpty() ||
        txtHistorial.getText().trim().isEmpty() || txtGrupoSanguineo.getText().trim().isEmpty() ||
        (!jMasculino.isSelected() && !jFemenino.isSelected()) || txtAlergias.getText().trim().isEmpty() ||
        txtPeso.getText().trim().isEmpty() || txtEstatura.getText().trim().isEmpty() ||
        txtFechaNaci.getText().trim().isEmpty() || txtInstrucciones.getText().trim().isEmpty() ||
        txtMediPres.getText().trim().isEmpty() || txtFechaEmicion.getText().trim().isEmpty()) { // Campo de fecha de receta
        
        JOptionPane.showMessageDialog(null, "Error: Todos los campos deben estar llenos.");
        return;
    }

    Long pacienteId;
    Long recetaId;
    try {
        pacienteId = Long.parseLong(txtId.getText().trim());
        recetaId = Long.parseLong(txtNumReceta.getText().trim());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Error: El ID del paciente y el número de receta deben ser números.");
        return;
    }

    // Validaciones específicas
    String nombreCompleto = txtNombreC.getText().trim();
    if (!nombreCompleto.matches("[a-zA-Z\\s]+")) {
        JOptionPane.showMessageDialog(null, "Error: El nombre completo no puede contener números ni caracteres especiales.");
        return;
    }

    String numeroIdentificacion = txtCurp.getText().trim();
    if (numeroIdentificacion.length() < 18) {
        JOptionPane.showMessageDialog(null, "Error: El número de identificación debe tener al menos 18 caracteres.");
        return;
    }

    String telefono = txtTelefono.getText().trim();
    if (!telefono.matches("\\d{10}")) {
        JOptionPane.showMessageDialog(null, "Error: El teléfono debe contener exactamente 10 dígitos.");
        return;
    }

    String correoElectronico = txtCorreoEle.getText().trim();
    if (!correoElectronico.matches("^[\\w-.]+@[\\w-]+\\.[a-zA-Z]{2,}$")) {
        JOptionPane.showMessageDialog(null, "Error: El correo electrónico no tiene un formato válido.");
        return;
    }

    String grupoSanguineo = txtGrupoSanguineo.getText().trim();
    if (!grupoSanguineo.matches("^(A[\\+\\-]|B[\\+\\-]|AB[\\+\\-]|O[\\+\\-])$")) {
        JOptionPane.showMessageDialog(null, "Error: El grupo sanguíneo debe ser A+, A-, B+, B-, AB+, AB-, O+ o O-.");
        return;
    }

    String pesoStr = txtPeso.getText().trim();
    if (!pesoStr.matches("\\d+")) {
        JOptionPane.showMessageDialog(null, "Error: El peso debe ser un número válido.");
        return;
    }

    String estaturaStr = txtEstatura.getText().trim();
    if (!estaturaStr.matches("\\d+")) {
        JOptionPane.showMessageDialog(null, "Error: La estatura debe ser un número válido.");
        return;
    }

    // Validar fecha de nacimiento
    java.sql.Date fechaNacimiento;
    String fechaNaciStr = txtFechaNaci.getText().trim();
    try {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false); // Para asegurar que la fecha sea válida
        java.util.Date fechaUtil = sdf.parse(fechaNaciStr);
        fechaNacimiento = new java.sql.Date(fechaUtil.getTime());

        // Validar si la fecha es válida
        Calendar cal = Calendar.getInstance();
        cal.setTime(fechaUtil);
        int dia = cal.get(Calendar.DAY_OF_MONTH);
        int mes = cal.get(Calendar.MONTH) + 1; // Los meses empiezan en 0
        int año = cal.get(Calendar.YEAR);
        
        if (mes == 2) { // Febrero
            boolean bisiesto = (año % 4 == 0 && (año % 100 != 0 || año % 400 == 0));
            if (dia > 29 || (dia == 29 && !bisiesto)) {
                JOptionPane.showMessageDialog(null, "Error: Fecha de nacimiento inválida.");
                return;
            }
        } else if (dia > 31 || (mes == 4 || mes == 6 || mes == 9 || mes == 11 && dia > 30)) {
            JOptionPane.showMessageDialog(null, "Error: Fecha de nacimiento inválida.");
            return;
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: Formato de fecha de nacimiento inválido. Use 'yyyy-MM-dd'.");
        return;
    }

    // Validar fecha de la receta
    java.sql.Date fechaReceta;
    String fechaRecetaStr = txtFechaEmicion.getText().trim();
    try {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false); // Para asegurar que la fecha sea válida
        fechaReceta = new java.sql.Date(sdf.parse(fechaRecetaStr).getTime());
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: Formato de fecha de la receta inválido. Use 'yyyy-MM-dd'.");
        return;
    }

    try {  
        em.getTransaction().begin();

        Paciente paciente = em.find(Paciente.class, pacienteId);
        if (paciente == null) {
            JOptionPane.showMessageDialog(null, "Error: No se encontró el paciente con ID: " + pacienteId);
            return; 
        }

        // Comprobar si ya existe un paciente con el mismo número de identificación
        TypedQuery<Paciente> query = em.createQuery("SELECT p FROM Paciente p WHERE p.numeroIdentificacion = :numeroIdentificacion AND p.id <> :pacienteId", Paciente.class);
        query.setParameter("numeroIdentificacion", numeroIdentificacion);
        query.setParameter("pacienteId", pacienteId);

        if (!query.getResultList().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: Ya existe un paciente con ese número de identificación.");
            return; 
        }

        // Asignar nuevos valores al paciente
        paciente.setNombreCompleto(nombreCompleto);
        paciente.setNumeroIdentificacion(numeroIdentificacion);
        paciente.setDireccion(txtDireccion.getText().trim());
        paciente.setTelefono(telefono);
        paciente.setCorreoElectronico(correoElectronico);
        paciente.setNacionalidad(txtNacionalidad.getText().trim());
        paciente.setHistorialMedico(txtHistorial.getText().trim());
        paciente.setGrupoSanguineo(grupoSanguineo);
        paciente.setSexo(jMasculino.isSelected() ? "Masculino" : "Femenino");
        paciente.setAlergias(txtAlergias.getText().trim());
        paciente.setFechaNacimiento(fechaNacimiento); 

        // Asignar peso y estatura
        paciente.setPeso(Integer.parseInt(pesoStr)); 
        paciente.setEstatura(Long.parseLong(estaturaStr)); 

        // Modificar o crear receta
        Receta receta = em.find(Receta.class, recetaId);
        if (receta != null) {
            receta.setMedicamentosPrescritos(txtMediPres.getText().trim());
            receta.setInstruccionesAdicionales(txtInstrucciones.getText().trim());
            receta.setFechaEmision(fechaReceta); // Asignar la fecha de la receta
            em.merge(receta); 
        } else {         
            receta = new Receta();
            receta.setPaciente(paciente);
            receta.setMedicamentosPrescritos(txtMediPres.getText().trim());
            receta.setInstruccionesAdicionales(txtInstrucciones.getText().trim());
            receta.setFechaEmision(fechaReceta); // Asignar la fecha de la receta
            em.persist(receta); 
        }        

        em.getTransaction().commit();
        JOptionPane.showMessageDialog(null, "Los datos del paciente y las recetas han sido modificados exitosamente.");

    } catch (Exception e) {
        em.getTransaction().rollback();
        JOptionPane.showMessageDialog(null, "Error al modificar los datos: " + e.getMessage());
    }

    
    }//GEN-LAST:event_btmModificarActionPerformed

    private void txtMediPresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMediPresActionPerformed
       
    }//GEN-LAST:event_txtMediPresActionPerformed

    private void btmMedicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmMedicoActionPerformed
  
    Vmedico vistaMedico = new Vmedico(); 
    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
    frame.setContentPane(vistaMedico);
    frame.revalidate(); 
    frame.repaint(); 
    }//GEN-LAST:event_btmMedicoActionPerformed

    private void btmEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmEliminarActionPerformed
        int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de que desea eliminar al paciente y todas sus recetas?", 
            "Confirmar eliminación", 
            JOptionPane.YES_NO_OPTION);   
    if (confirmacion == JOptionPane.YES_OPTION) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {           
            Long pacienteId = Long.parseLong(txtId.getText());
            transaction.begin();  
            Paciente paciente = em.find(Paciente.class, pacienteId);
            if (paciente != null) {           
                String jpqlRecetas = "DELETE FROM Receta r WHERE r.paciente.id = :pacienteId";
                em.createQuery(jpqlRecetas)
                  .setParameter("pacienteId", pacienteId)
                  .executeUpdate();          
                em.remove(em.contains(paciente) ? paciente : em.merge(paciente));
                transaction.commit();
                JOptionPane.showMessageDialog(this, "Paciente y sus recetas eliminados correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró el paciente con ID: " + pacienteId);
            }
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar el paciente.");
        } finally {
            em.close();
        }
    } else {
    
        JOptionPane.showMessageDialog(this, "Eliminación cancelada.");
    }
    }//GEN-LAST:event_btmEliminarActionPerformed

    private void btmCitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmCitasActionPerformed
    CitasU_1 vistaCitas = new CitasU_1(); 
    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
    frame.setContentPane(vistaCitas);
    frame.revalidate(); 
    frame.repaint(); 
    }//GEN-LAST:event_btmCitasActionPerformed
public void loadPatients() {
        try {
            
            Query query = entityManager.createQuery("SELECT p FROM Paciente p");
            List<Paciente> pacientes = query.getResultList();

            for (Paciente paciente : pacientes) {
                System.out.println("Paciente: " + paciente.getNombreCompleto());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (entityManager != null && entityManager.isOpen()) {
                entityManager.close();
            }
        }
    }


private void updatePatientTable() {
        tableModel = new DefaultTableModel(new Object[]{"ID", "Nombre", "Fecha Nacimiento", "Sexo", "Teléfono"}, 0);
        for (Paciente paciente : pacientes) {
            tableModel.addRow(new Object[]{paciente.getId(), paciente.getNombreCompleto(), paciente.getFechaNacimiento(), paciente.getSexo(), paciente.getTelefono()});
        }
        
    }


private void clearFields() {
        txtId.setText("");
        txtNombreC.setText("");
        txtFechaNaci.setText("");
        txtTelefono.setText("");
        txtAlergias.setText("");
        txtCurp.setText("");
        txtCorreoEle.setText("");
        txtDireccion.setText("");
        txtHistorial.setText("");
        txtNacionalidad.setText("");
         jMasculino.setSelected(false);
        jFemenino.setSelected(false);
        txtPeso.setText("");
        txtEstatura.setText("");
        
  
    }

private void clearRecetaFields() {
    txtFechaEmicion.setText("");
    txtNumReceta.setText("");
   txtIdMedico.setText("");
    txtMediPres.setText("");
    txtInstrucciones.setText("");
}
 boolean validateFields() {
        if (txtNombreC.getText().isEmpty() || txtFechaNaci.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor complete todos los campos obligatorios");
            return false;
        }
        return true;
    }
  public void close() {
        if (em != null) {
            em.close();
        }
        if (emf != null) {
            emf.close();
        }
    }
  
  private Date convertirStringADate(String fechaStr) {
        try {
            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            java.util.Date fechaUtil = formato.parse(fechaStr);
            return new Date(fechaUtil.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return null; 
        }
    }
  private boolean esAnioBisiesto(int anio) {
    return (anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0);

}
  
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmBuscar;
    private javax.swing.JButton btmCitas;
    private javax.swing.JButton btmEliminar;
    private javax.swing.JButton btmGuardar;
    private javax.swing.JToggleButton btmMedico;
    private javax.swing.JButton btmModificar;
    private javax.swing.JButton btmNuevo;
    private javax.swing.JButton btmSalir;
    private javax.swing.JRadioButton jFemenino;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JRadioButton jMasculino;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel jlAlergias;
    private javax.swing.JLabel jlCorreoE;
    private javax.swing.JLabel jlCurp;
    private javax.swing.JLabel jlDireccion;
    private javax.swing.JLabel jlFechaEmision;
    private javax.swing.JLabel jlFechaNacimiento;
    private javax.swing.JLabel jlGrupoSnaguineo;
    private javax.swing.JLabel jlHistorial;
    private javax.swing.JLabel jlId;
    private javax.swing.JLabel jlIdMedico;
    private javax.swing.JLabel jlInstrucciones;
    private javax.swing.JLabel jlMediPresc;
    private javax.swing.JLabel jlNacionalidad;
    private javax.swing.JLabel jlNumReceta;
    private javax.swing.JLabel jlPeso;
    private javax.swing.JLabel jlRECETA;
    private javax.swing.JLabel jlSexo;
    private javax.swing.JLabel jlTelefono;
    private javax.swing.JTextArea txtAlergias;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCorreoEle;
    private javax.swing.JTextField txtCurp;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEstatura;
    private javax.swing.JTextField txtFechaEmicion;
    private javax.swing.JTextField txtFechaNaci;
    private javax.swing.JTextField txtGrupoSanguineo;
    private javax.swing.JTextArea txtHistorial;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtIdMedico;
    private javax.swing.JTextField txtInstrucciones;
    private javax.swing.JTextField txtMediPres;
    private javax.swing.JTextField txtNacionalidad;
    private javax.swing.JTextField txtNombreC;
    private javax.swing.JTextField txtNumReceta;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
