/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import Datos.Medico;
import Datos.Session;
import Datos.Usuario;
import java.awt.BorderLayout;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.SwingUtilities;

/**
 *
 * @author PC
 */
public class Vmedico extends javax.swing.JPanel {

    private EntityManagerFactory emf;
    private EntityManager em;
    private String numeroControlActual;
    
    public Vmedico() {
        initComponents();
        emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();
        cargarDatos();
    }
    
    private void cargarDatos() {
        
        Usuario usuarioActual = obtenerUsuarioActual();

        if (usuarioActual != null) {
            cargarDatosMedico(usuarioActual.getNombre());
        } else {
            JOptionPane.showMessageDialog(this, "Error: No hay un usuario autenticado.");
        }
    }

    private Usuario obtenerUsuarioActual() {
      
        Usuario usuario = Session.getCurrentUser();
        if (usuario != null) {
            System.out.println("Usuario actual: " + usuario.getNombre());
        } else {
            System.out.println("No hay usuario autenticado.");
        }
        return usuario;
    }

    private void cargarDatosMedico(String nombreUsuario) {
        EntityManager em = emf.createEntityManager();
        try {
            
            String jpql = "SELECT m FROM Medico m WHERE m.nombreCompleto = :nombreCompleto";
            Medico medico = em.createQuery(jpql, Medico.class)
                                  .setParameter("nombreCompleto", nombreUsuario)
                                  .getSingleResult();

            if (medico != null) {
                
                mostrarDatosMedico(medico);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un medico con ese nombre.");
            }
        } catch (NoResultException e) {
            JOptionPane.showMessageDialog(this, "No se encontró un medico con ese nombre.");
        } catch (Exception e) {
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(this, "Error al cargar los datos del medico.");
        } finally {
            em.close();
        }
    }
    private void mostrarDatosMedico(Medico medico) {
        txtNombre.setText(medico.getNombreCompleto());
        txtLicencia.setText(medico.getNumeroLicencia());
        txtNumeroControl.setText(String.valueOf(medico.getId()));
        txtEspecilidad.setText(medico.getEspecialidad());
        txtTelefono.setText(medico.getTelefono());
        txtCurp.setText(medico.getCurp());
        txtDireccion.setText(medico.getDireccionConsultorio());
        txtCorreoElec.setText(medico.getCorreoElectronico());
        
        
    }
    
    
    
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jlCurp = new javax.swing.JLabel();
        txtCurp = new javax.swing.JTextField();
        txtLicencia = new javax.swing.JTextField();
        jlLicencia = new javax.swing.JLabel();
        jlEspecialidad = new javax.swing.JLabel();
        txtEspecilidad = new javax.swing.JTextField();
        jlTelefono = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        jlNumeroControl = new javax.swing.JLabel();
        txtNumeroControl = new javax.swing.JTextField();
        jlDireccion = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        jlCorreoElect = new javax.swing.JLabel();
        txtCorreoElec = new javax.swing.JTextField();
        btmSalir = new javax.swing.JToggleButton();
        btmModificar = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btmRegresar = new javax.swing.JButton();

        jlNombre.setText("Nombre:");

        jlCurp.setText("CURP:");

        jlLicencia.setText("Numero de licencia:");

        jlEspecialidad.setText("Especialidad:");

        jlTelefono.setText("Telefono:");

        jlNumeroControl.setText("Numero de control:");

        jlDireccion.setText("Direccion:");

        jlCorreoElect.setText("Correo Electronico:");

        btmSalir.setText("Salir");
        btmSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmSalirActionPerformed(evt);
            }
        });

        btmModificar.setText("Modificar");
        btmModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmModificarActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 153, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 863, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/9634072.png"))); // NOI18N

        btmRegresar.setText("Regresar");
        btmRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jlCorreoElect)
                                    .addComponent(jlDireccion)
                                    .addComponent(jlTelefono)
                                    .addComponent(jlCurp))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtCurp)
                                    .addComponent(txtTelefono)
                                    .addComponent(txtDireccion)
                                    .addComponent(txtCorreoElec, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btmModificar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btmSalir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btmRegresar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(136, 136, 136))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jlNumeroControl)
                                    .addComponent(jlEspecialidad)
                                    .addComponent(jlLicencia)
                                    .addComponent(jlNombre))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNombre)
                                    .addComponent(txtLicencia)
                                    .addComponent(txtEspecilidad)
                                    .addComponent(txtNumeroControl, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtLicencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlLicencia))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlNumeroControl)
                            .addComponent(txtNumeroControl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlNombre)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlEspecialidad)
                            .addComponent(txtEspecilidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 98, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlTelefono)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(39, 39, 39))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btmModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlCurp)
                    .addComponent(txtCurp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btmSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlDireccion)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(btmRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCorreoElec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlCorreoElect))
                .addGap(162, 162, 162)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btmSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmSalirActionPerformed
       System.exit(0);
    }//GEN-LAST:event_btmSalirActionPerformed

    private void btmModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmModificarActionPerformed
      
    Long medicoId = Long.parseLong(txtNumeroControl.getText().trim()); 
  
    JPasswordField passwordField = new JPasswordField();
    int option = JOptionPane.showConfirmDialog(this, passwordField, "Por favor, ingrese su contraseña:", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    
    if (option == JOptionPane.CANCEL_OPTION || option == JOptionPane.CLOSED_OPTION) {
        return; 
    }
  
    String contraseñaIngresada = new String(passwordField.getPassword());

    if (contraseñaIngresada.trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "La contraseña no puede estar vacía.");
        return;
    }
    try {
        em.getTransaction().begin();
        Medico medico = em.find(Medico.class, medicoId);
        
        if (medico == null) {
            JOptionPane.showMessageDialog(null, "Error: No se encontró el médico con ID: " + medicoId);
            return; 
        }

     
        if (!medico.getContraseña().equals(contraseñaIngresada)) {
            JOptionPane.showMessageDialog(null, "Error: Contraseña incorrecta.");
            return; 
        }

        
        String nombreCompleto = txtNombre.getText().trim();
        String numeroLicencia = txtLicencia.getText().trim();
        String especialidad = txtEspecilidad.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String correoElectronico = txtCorreoElec.getText().trim();
        String curp = txtCurp.getText().trim();
        String direccion = txtDireccion.getText().trim();

       
        TypedQuery<Medico> query = em.createQuery("SELECT m FROM Medico m WHERE m.numeroLicencia = :numeroLicencia AND m.id <> :medicoId", Medico.class);
        query.setParameter("numeroLicencia", numeroLicencia);
        query.setParameter("medicoId", medicoId);

        if (!query.getResultList().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: Ya existe un médico con ese número de licencia.");
            return; 
        }

       
        medico.setNombreCompleto(nombreCompleto);
        medico.setNumeroLicencia(numeroLicencia);
        medico.setEspecialidad(especialidad);
        medico.setTelefono(telefono);
        medico.setCorreoElectronico(correoElectronico);
        medico.setCurp(curp);
        medico.setDireccionConsultorio(direccion);

       
        em.getTransaction().commit();
        JOptionPane.showMessageDialog(null, "Los datos del médico han sido modificados exitosamente.");

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el médico: " + e.getMessage());

        if (em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
    }
    
    }//GEN-LAST:event_btmModificarActionPerformed

    private void btmRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmRegresarActionPerformed
     JFrame framePrincipal = (JFrame) SwingUtilities.getWindowAncestor(this);

    
    AdminPaciente paciente = new AdminPaciente();

   
    framePrincipal.setLayout(new BorderLayout());

    
    framePrincipal.getContentPane().removeAll();
    framePrincipal.getContentPane().add(paciente, BorderLayout.CENTER);

   
    framePrincipal.revalidate();
    framePrincipal.repaint();
    }//GEN-LAST:event_btmRegresarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btmModificar;
    private javax.swing.JButton btmRegresar;
    private javax.swing.JToggleButton btmSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jlCorreoElect;
    private javax.swing.JLabel jlCurp;
    private javax.swing.JLabel jlDireccion;
    private javax.swing.JLabel jlEspecialidad;
    private javax.swing.JLabel jlLicencia;
    private javax.swing.JLabel jlNombre;
    private javax.swing.JLabel jlNumeroControl;
    private javax.swing.JLabel jlTelefono;
    private javax.swing.JTextField txtCorreoElec;
    private javax.swing.JTextField txtCurp;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEspecilidad;
    private javax.swing.JTextField txtLicencia;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumeroControl;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
