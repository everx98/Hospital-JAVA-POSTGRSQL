/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import Datos.Citas;
import Datos.Paciente;
import Datos.Session;
import Datos.Usuario;
import com.toedter.calendar.IDateEvaluator;
import java.awt.Color;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;


public class CitasU_1 extends javax.swing.JPanel {
private EntityManagerFactory emf;
    private EntityManager em;
    private List<Date> fechasOcupadas;
  
    public CitasU_1() {
      initComponents();
        emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();
        cargarDatos();
        deshabilitarFechasOcupadas();
    }
    private void cargarDatos() {
    System.out.println("Cargando datos...");
    Usuario usuarioActual = obtenerUsuarioActual(); 
    try {
    if (usuarioActual != null) {
        System.out.println("Usuario encontrado: " + usuarioActual.getNombre());
        cargarDatosCitas(usuarioActual.getNombre());
    } else {
        System.out.println("No se encontró un usuario autenticado.");
        JOptionPane.showMessageDialog(this, "Error: No hay un usuario autenticado.");
    }
} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Error al cargar los datos: " + e.getMessage());
}
}
    private void cargarDatosCitas(String nombreUsuario) {
    System.out.println("Cargando citas para el usuario: " + nombreUsuario);
    
    EntityManager em = emf.createEntityManager();
        String jpql = "SELECT c FROM Citas c WHERE c.nombrePaciente = :nombrePaciente";
        List<Citas> citas = em.createQuery(jpql, Citas.class)
                              .setParameter("nombrePaciente", nombreUsuario)
                              .getResultList();
        
        System.out.println("Número de citas encontradas: " + citas.size()); // Verificación de cuántas citas se encontraron
        
       
}
    
    

    
    private Usuario obtenerUsuarioActual() {
    Usuario usuario = Session.getCurrentUser();
    if (usuario != null) {
        System.out.println("Usuario actual: " + usuario.getNombre());
    } else {
        System.out.println("No hay usuario autenticado.");
    }
    return usuario;
}
    private List<Date> obtenerFechasOcupadas() {
    List<Date> fechas = new ArrayList<>();
    try {
        String jpql = "SELECT c.fecha FROM Citas c";
        fechas = em.createQuery(jpql, Date.class).getResultList();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return fechas != null ? fechas : new ArrayList<>(); 
}

private void deshabilitarFechasOcupadas() {
   
    if (fechasOcupadas == null) {
        fechasOcupadas = obtenerFechasOcupadas();  
    }

    jFecha.getJCalendar().getDayChooser().addDateEvaluator(new IDateEvaluator() {
        @Override
        public boolean isSpecial(Date date) {
            return false;
        }

        @Override
        public Color getSpecialForegroundColor() {
            return null;
        }

        @Override
        public Color getSpecialBackroundColor() {
            return null;
        }

        @Override
        public String getSpecialTooltip() {
            return null;
        }

        @Override
        public boolean isInvalid(Date date) {
          
            if (fechasOcupadas != null) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                for (Date fecha : fechasOcupadas) {
                    Calendar calOcupada = Calendar.getInstance();
                    calOcupada.setTime(fecha);
                    if (cal.get(Calendar.YEAR) == calOcupada.get(Calendar.YEAR) &&
                        cal.get(Calendar.MONTH) == calOcupada.get(Calendar.MONTH) &&
                        cal.get(Calendar.DAY_OF_MONTH) == calOcupada.get(Calendar.DAY_OF_MONTH)) {
                        return true;  
                    }
                }
            }
            return false;
        }

        @Override
        public Color getInvalidForegroundColor() {
            return Color.RED;
        }

        @Override
        public Color getInvalidBackroundColor() {
            return Color.LIGHT_GRAY;
        }

        @Override
        public String getInvalidTooltip() {
            return "Fecha no disponible";
        }
    });
}

     

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jFecha = new com.toedter.calendar.JDateChooser();
        CCita = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtCitaEstado = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtIdCita = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        btmAgendar = new javax.swing.JButton();
        btmCancelar = new javax.swing.JButton();
        btmRegresar = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setText("Fecha de la cita:");

        jLabel2.setText("Nombre del paciente:");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jLabel3.setText("Hora de la cita:");

        CCita.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Escoge una hora", "9:00 AM", "10:00 AM", "11:00 AM", "12:00 AM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM", "6:00 PM", " " }));
        CCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CCitaActionPerformed(evt);
            }
        });

        jLabel4.setText("Estado de la cita:");

        txtCitaEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCitaEstadoActionPerformed(evt);
            }
        });

        jLabel5.setText("Id");

        txtIdCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdCitaActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
        );

        btmAgendar.setText("Agendar");
        btmAgendar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmAgendarActionPerformed(evt);
            }
        });

        btmCancelar.setText("Cancelar");
        btmCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmCancelarActionPerformed(evt);
            }
        });

        btmRegresar.setText("Regresar");
        btmRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmRegresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtIdCita, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jFecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CCita, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btmAgendar, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10))
                            .addComponent(jLabel4)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtNombre)
                                .addComponent(txtCitaEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btmCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(btmRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(272, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtIdCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(CCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(jFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtCitaEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btmAgendar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btmCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(btmRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(69, 69, 69)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtCitaEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCitaEstadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCitaEstadoActionPerformed

    private void txtIdCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdCitaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdCitaActionPerformed

    private void btmAgendarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmAgendarActionPerformed
        
      
    Citas cita = new Citas();
    
   
    if (jFecha.getDate() == null || txtNombre.getText().isEmpty()
            || CCita.getSelectedIndex() == 0) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar llenos.");
        return;
    }
    
    long idCitaAleatorio = (long) (Math.random() * 9000L) + 1000L;
    
    Date fechaSeleccionada = jFecha.getDate();
    String estado = txtCitaEstado.getText();  
    String idCitas = txtIdCita.getText();
    String nombre = txtNombre.getText();
    
   String hora = CCita.getSelectedItem().toString();
    cita.setId(idCitaAleatorio);
    cita.setFecha(fechaSeleccionada);
    cita.setEstado(estado);  
    cita.setNombrePaciente(nombre);
    cita.setHora(hora); 
    cita.setEstado("agendada");
   
      txtIdCita.setText(String.valueOf(idCitaAleatorio));
    try {
        em.getTransaction().begin();
        em.persist(cita); 
        em.getTransaction().commit();
        JOptionPane.showMessageDialog(null, "Cita agendada con éxito.");
        
        
        txtCitaEstado.setText("Agendada");
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al guardar la cita: " + e.getMessage());
        if (em.getTransaction().isActive()) {
            em.getTransaction().rollback();
        }
        
    }
    
  



     
       
    }//GEN-LAST:event_btmAgendarActionPerformed

    private void btmCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmCancelarActionPerformed
       int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Está seguro de que desea cancelar tu cita?", 
            "Confirmar cancelacion", 
            JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();
        try {
         Long id= Long.parseLong(txtIdCita.getText());
         transaction.begin(); 
         Citas cita=em.find(Citas.class,id);
         if (cita != null) {
                em.remove(cita);
                transaction.commit();
                JOptionPane.showMessageDialog(this, "Cita cancelada correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró la cita.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            JOptionPane.showMessageDialog(this, "Error al cancelar la cita: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            em.close();
            emf.close();
        }
    }
             
     
       
    }//GEN-LAST:event_btmCancelarActionPerformed

    private void CCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CCitaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CCitaActionPerformed

    private void btmRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmRegresarActionPerformed
    AdminPaciente vistaPaciente = new AdminPaciente(); 
    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
    frame.setContentPane(vistaPaciente);
    frame.revalidate(); 
    frame.repaint(); 
    }//GEN-LAST:event_btmRegresarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CCita;
    private javax.swing.JButton btmAgendar;
    private javax.swing.JButton btmCancelar;
    private javax.swing.JButton btmRegresar;
    private com.toedter.calendar.JDateChooser jFecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtCitaEstado;
    private javax.swing.JTextField txtIdCita;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables


}
