/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import Datos.Rol;
import Datos.Session;
import Datos.Usuario;
import java.awt.BorderLayout;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author PC
 */
public class login extends javax.swing.JPanel {
    private EntityManagerFactory emf;
    private EntityManager em;

    /**
     * Creates new form login
     */
    public login() {
        initComponents();
        emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();
    }

    @SuppressWarnings("unchecked")
    
    // Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lbUsuario = new javax.swing.JLabel();
        lbContraseña = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        txtContraseña = new javax.swing.JPasswordField();
        btmIniciar = new javax.swing.JButton();
        btmCancelar = new javax.swing.JButton();
        btmCrearCuenta = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        lbUsuario.setText("Numero de control:");

        lbContraseña.setText("Contraseña:");

        btmIniciar.setText("Iniciar");
        btmIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmIniciarActionPerformed(evt);
            }
        });

        btmCancelar.setText("Cancelar");
        btmCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmCancelarActionPerformed(evt);
            }
        });

        btmCrearCuenta.setText("Crear cuenta");
        btmCrearCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmCrearCuentaActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/doctor-owl-illustration-png.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addGroup(jPanel1Layout
                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(btmCrearCuenta, javax.swing.GroupLayout.Alignment.TRAILING,
                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lbContraseña, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lbUsuario, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(44, 44, 44)
                                                .addComponent(btmIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 95,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED,
                                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(btmCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 95,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(79, 79, 79)
                                                .addGroup(jPanel1Layout
                                                        .createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING,
                                                                false)
                                                        .addComponent(txtUsuario)
                                                        .addComponent(txtContraseña,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE, 228,
                                                                javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(47, 47, 47))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1)
                                .addGap(203, 203, 203)));
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 147,
                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(lbUsuario)
                                        .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(30, 30, 30)
                                                .addComponent(lbContraseña))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 36,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(60, 60, 60)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(btmIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btmCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btmCrearCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 34,
                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(38, 38, 38)));

        jPanel3.setBackground(new java.awt.Color(0, 153, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE));
        jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 36, Short.MAX_VALUE));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap())
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
                                javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addContainerGap()));
    }// </editor-fold>//GEN-END:initComponents

    private void btmCancelarActionPerformed(java.awt.event.ActionEvent evt) {
        System.exit(0);
    }

    private void btmIniciarActionPerformed(java.awt.event.ActionEvent evt) {

        String numeroControl = txtUsuario.getText();
    String contraseña = new String(txtContraseña.getPassword());

    EntityManager em = null;
    try {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();

        // Consulta JPQL para buscar al usuario por número de control y contraseña
        String jpql = "SELECT u FROM Usuario u WHERE u.numeroControl = :numeroControl AND u.contraseña = :contraseña";
        Usuario usuario = em.createQuery(jpql, Usuario.class)
                .setParameter("numeroControl", numeroControl)
                .setParameter("contraseña", contraseña)
                .getSingleResult();

        // Si el usuario es válido
        if (usuario != null) {
            // Guardar la sesión del usuario actual
            Session.setCurrentUser(usuario);
            
            // Obtener el nombre y rol del usuario
            String nombre = usuario.getNombre();
            Rol rol = usuario.getRol();

            if (rol != null) {
                String rolNombre = rol.getNombre();
                JOptionPane.showMessageDialog(this, "Bienvenido, " + nombre + " (" + rolNombre + ")");

                // Crear el nuevo JFrame
                JFrame frame = new JFrame();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                // Mostrar la vista correspondiente según el rol
                if ("medico".equalsIgnoreCase(rolNombre)) {
                    AdminPaciente adminView = new AdminPaciente();
                    frame.getContentPane().add(adminView);  // Asegura que el contenido se añade correctamente
                } else if ("usuarios".equalsIgnoreCase(rolNombre)) {
                    Upaciente usuarioView = new Upaciente();
                    frame.getContentPane().add(usuarioView);  // Asegura que el contenido se añade correctamente
                }

               
                frame.setSize(1000, 800);
                frame.setVisible(true);
                SwingUtilities.getWindowAncestor(this).dispose();
            } else {
                JOptionPane.showMessageDialog(this, "El usuario no tiene un rol asignado.");
            }
        }
    } catch (NoResultException e) {
        JOptionPane.showMessageDialog(this, "Credenciales incorrectas");
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error de conexión o credenciales incorrectas");
    } finally {
        if (em != null) {
            em.close();
        }
    }
    }

    private void btmCrearCuentaActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btmCrearCuentaActionPerformed
        JFrame framePrincipal = (JFrame) SwingUtilities.getWindowAncestor(this);

        CrearCuenta crearCuentaPanel = new CrearCuenta();

        framePrincipal.setLayout(new BorderLayout());

        framePrincipal.getContentPane().removeAll();
        framePrincipal.getContentPane().add(crearCuentaPanel, BorderLayout.CENTER);

        framePrincipal.revalidate();
        framePrincipal.repaint();

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmCancelar;
    private javax.swing.JButton btmCrearCuenta;
    private javax.swing.JButton btmIniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lbContraseña;
    private javax.swing.JLabel lbUsuario;
    private javax.swing.JPasswordField txtContraseña;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables

}
