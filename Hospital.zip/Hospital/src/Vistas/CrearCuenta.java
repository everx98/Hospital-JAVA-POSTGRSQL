/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import Datos.Rol;
import Datos.Usuario;
import java.awt.BorderLayout;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author PC
 */
public class CrearCuenta extends javax.swing.JPanel {

    private EntityManagerFactory emf;
    private EntityManager em;
    public CrearCuenta() {
        initComponents();
        emf = Persistence.createEntityManagerFactory("HospitalPU");
        em = emf.createEntityManager();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtNumControl = new javax.swing.JTextField();
        jlNumControl = new javax.swing.JLabel();
        jlContraseña = new javax.swing.JLabel();
        txtContraseña = new javax.swing.JPasswordField();
        btmCrear = new javax.swing.JButton();
        btmRegresar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 255, 255));

        jlNombre.setText("Nombre completo:");

        jlNumControl.setText("Numero de control:");

        jlContraseña.setText("Constraseña:");

        txtContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtContraseñaActionPerformed(evt);
            }
        });

        btmCrear.setText("Crear");
        btmCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmCrearActionPerformed(evt);
            }
        });

        btmRegresar.setText("Regresar");
        btmRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmRegresarActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 55, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btmCrear)
                    .addComponent(jlContraseña)
                    .addComponent(jlNombre)
                    .addComponent(jlNumControl))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNumControl)
                            .addComponent(txtNombre)
                            .addComponent(txtContraseña, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(btmRegresar)))
                .addContainerGap(155, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlNombre)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumControl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlNumControl))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlContraseña)
                    .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btmCrear)
                    .addComponent(btmRegresar))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtContraseñaActionPerformed

    private void btmCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmCrearActionPerformed
  
   String nombre = txtNombre.getText().trim();
String numeroControl = txtNumControl.getText().trim();
String contraseña = new String(txtContraseña.getPassword());

if (nombre.isEmpty() || numeroControl.isEmpty() || contraseña.isEmpty()) {
    JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
    return;
}


String passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{12,}$";

if (!contraseña.matches(passwordPattern)) {
    JOptionPane.showMessageDialog(null, "La contraseña debe tener al menos 12 caracteres, incluir mayúsculas, números y caracteres especiales.");
    return;
}

EntityManagerFactory emf = Persistence.createEntityManagerFactory("HospitalPU");
EntityManager em = emf.createEntityManager();

try {
    em.getTransaction().begin();

    Usuario nuevoUsuario = new Usuario();
    nuevoUsuario.setNombre(nombre);
    nuevoUsuario.setNumeroControl(numeroControl);
    nuevoUsuario.setContraseña(contraseña);

    TypedQuery<Rol> query = em.createQuery("SELECT r FROM Rol r WHERE r.id = :rolId", Rol.class);
    query.setParameter("rolId", 2); 
    Rol rolUsuario = query.getSingleResult();
    nuevoUsuario.setRol(rolUsuario); 

    em.persist(nuevoUsuario);

    em.getTransaction().commit();

    JOptionPane.showMessageDialog(null, "Cuenta creada exitosamente con rol de usuario.");
} catch (Exception e) {
    if (em.getTransaction().isActive()) {
        em.getTransaction().rollback();
    }
    JOptionPane.showMessageDialog(null, "Error al crear la cuenta: " + e.getMessage());
} finally {
    em.close();
}
    
    }//GEN-LAST:event_btmCrearActionPerformed

    private void btmRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmRegresarActionPerformed
        JFrame framePrincipal = (JFrame) SwingUtilities.getWindowAncestor(this);

   
    login Login = new login();

    
    framePrincipal.setLayout(new BorderLayout());

    
    framePrincipal.getContentPane().removeAll();
    framePrincipal.getContentPane().add(Login, BorderLayout.CENTER);

   
    framePrincipal.revalidate();
    framePrincipal.repaint();
       
    }//GEN-LAST:event_btmRegresarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmCrear;
    private javax.swing.JButton btmRegresar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jlContraseña;
    private javax.swing.JLabel jlNombre;
    private javax.swing.JLabel jlNumControl;
    private javax.swing.JPasswordField txtContraseña;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNumControl;
    // End of variables declaration//GEN-END:variables
}
