/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author PC
 */
@Entity
@Table(name = "medicos")
public class Medico {
    
    @Id
    @Column (name="id")
    private Long id;  

    @Column(name = "nombre_completo", nullable = false)
    private String nombreCompleto;

    @Column(name = "numero_licencia", nullable = false)
    private String numeroLicencia; 

    @Column(name = "especialidad", nullable = false)
    private String especialidad; 

    @Column(name = "telefono")
    private String telefono;  

    @Column(name = "numero_identificacion")
    private String curp;  

    @Column(name = "direccion_consultorio")
    private String direccionConsultorio;  

    @Column(name = "correo_electronico")
    private String correoElectronico; 

    @Column(name = "usuario_id")
    private Integer usuarioId;
    
    @Column(name = "contraseña")
    private String contraseña;

 
    public Medico() {
    }

    public Medico(String nombreCompleto, String numeroLicencia, String especialidad, 
                  String telefono, String curp, String direccionConsultorio, 
                  String correoElectronico, Integer usuarioId,String contraseña) {
        this.nombreCompleto = nombreCompleto;
        this.numeroLicencia = numeroLicencia;
        this.especialidad = especialidad;
        this.telefono = telefono;
        this.curp = curp;
        this.direccionConsultorio = direccionConsultorio;
        this.correoElectronico = correoElectronico;
        this.usuarioId = usuarioId;
        this.contraseña=contraseña;
    }

   
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCurp() {
        return curp;
    }

    public void setCurp(String curp) {
        this.curp = curp;
    }

    public String getDireccionConsultorio() {
        return direccionConsultorio;
    }

    public void setDireccionConsultorio(String direccionConsultorio) {
        this.direccionConsultorio = direccionConsultorio;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public Integer getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Integer usuarioId) {
        this.usuarioId = usuarioId;
    }
    
    public void setContraseña (String contraseña){
        this.contraseña=contraseña;
    }
    
    public String getContraseña (){
        return contraseña;
    }

    @Override
    public String toString() {
   return "Medico{" +
            "id=" + id +
            ", nombreCompleto='" + nombreCompleto + '\'' +
            ", numeroLicencia='" + numeroLicencia + '\'' +
            ", especialidad='" + especialidad + '\'' +
            ", telefono='" + telefono + '\'' +
            ", curp='" + curp + '\'' +
            ", direccionConsultorio='" + direccionConsultorio + '\'' +
            ", correoElectronico='" + correoElectronico + '\'' +
            ", usuarioId=" + usuarioId +
            ", contraseña='" + contraseña + '\'' +
            '}';
    }
    
}
