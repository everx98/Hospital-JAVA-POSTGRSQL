/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.NoResultException;
import javax.persistence.Table;
import javax.persistence.TypedQuery;

/**
 *
 * @author PC
 */
@Entity
@Table(name = "usuarios", schema="public")
@NamedQueries({
    @NamedQuery(name = "Usuario.findAll", query = "SELECT u FROM Usuario u"),
    @NamedQuery(name = "Usuario.findByNumeroControl", query = "SELECT u FROM Usuario u WHERE u.numeroControl = :numeroControl"),
    @NamedQuery(name = "Usuario.findByRol", query = "SELECT u FROM Usuario u WHERE u.rol.nombre = :rolNombre")
})
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "numero_control", unique = true, nullable = false)
    private String numeroControl;

    @Column(name = "contraseña", nullable = false)
    private String contraseña;

    @ManyToOne
    @JoinColumn(name = "rol_id", referencedColumnName = "id")
    private Rol rol;

    @Column(name = "nombre", nullable = false)
    private String nombre;

  
    public Usuario() {
    }

    
    public Usuario(Long id, String numeroControl, String contraseña, Rol rol, String nombre) {
        this.id = id;
        this.numeroControl = numeroControl;
        this.contraseña = contraseña;
        this.rol = rol;
        this.nombre = nombre;
    }

    
    public static List<Usuario> findAll(EntityManager em) {
        TypedQuery<Usuario> query = em.createNamedQuery("Usuario.findAll", Usuario.class);
        return query.getResultList();
    }

    public static Usuario findByNumeroControl(EntityManager em, String numeroControl) {
        try {
            TypedQuery<Usuario> query = em.createNamedQuery("Usuario.findByNumeroControl", Usuario.class);
            query.setParameter("numeroControl", numeroControl);
            return query.getSingleResult();
        } catch (NoResultException e) {
            System.out.println("No se encontró el usuario con número de control: " + numeroControl);
            return null;
        } catch (Exception e) {
            e.printStackTrace(); 
            return null;
        }
    }

    public static List<Usuario> findByRol(EntityManager em, String rolNombre) {
        TypedQuery<Usuario> query = em.createNamedQuery("Usuario.findByRol", Usuario.class);
        query.setParameter("rolNombre", rolNombre);
        return query.getResultList();
    }

   
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNumeroControl() {
        return numeroControl;
    }

    public void setNumeroControl(String numeroControl) {
        this.numeroControl = numeroControl;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
     public boolean equals(Object obj) {
        if (this == obj) return true; 
        if (obj == null || getClass() != obj.getClass()) return false; 
        Usuario usuario = (Usuario) obj; 
        return Objects.equals(id, usuario.id) && 
               Objects.equals(numeroControl, usuario.numeroControl) && 
               Objects.equals(nombre, usuario.nombre) && 
               Objects.equals(rol, usuario.rol); 
    }

    @Override
    public String toString() {
        return "Usuario{" +
            "id=" + id +
            ", numeroControl='" + numeroControl + '\'' +
            ", nombre='" + nombre + '\'' +
            ", rol=" + (rol != null ? rol.getNombre() : "null") + 
            '}';
    }
}

    

