/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TypedQuery;

/**
 *
 * @author PC
 */
@Entity
@Table(name = "recetas")
@NamedQueries({
    @NamedQuery(name = "Receta.findAll", query = "SELECT r FROM Receta r"),
    @NamedQuery(name = "Receta.findByPaciente", query = "SELECT r FROM Receta r WHERE r.paciente.id = :pacienteId")
})
public class Receta implements Serializable {

    private static final long serialVersionUID = 1L;

    
   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)// para que genere el id de manera automatica y en orden numerico
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "paciente_id", nullable = false)
    private Paciente paciente;

    @ManyToOne
    @JoinColumn(name = "medico_id", nullable = false)
    private Medico medico;

    @Column(name = "fecha_emision", nullable = false)
    private Date fechaEmision; 
   
    @Column(name = "medicamentos_prescritos")
    private String medicamentosPrescritos;

    @Column(name = "instrucciones_adicionales")
    private String instruccionesAdicionales;

    // Constructor vacío
    public Receta() {}

    // Constructor completo
    public Receta(Long id, Paciente paciente, Medico medico, Date fechaEmision,
                  String medicamentosPrescritos, String instruccionesAdicionales) {
        this.id = id;
        this.paciente = paciente;
        this.medico = medico;
        this.fechaEmision = fechaEmision;
        this.medicamentosPrescritos = medicamentosPrescritos;
        this.instruccionesAdicionales = instruccionesAdicionales;
    }

   
    public static List<Receta> findAll(EntityManager em) {
        TypedQuery<Receta> query = em.createNamedQuery("Receta.findAll", Receta.class);
        return query.getResultList();
    }

    public static List<Receta> findByPaciente(EntityManager em, Long pacienteId) {
        TypedQuery<Receta> query = em.createNamedQuery("Receta.findByPaciente", Receta.class);
        query.setParameter("pacienteId", pacienteId);
        return query.getResultList();
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getMedicamentosPrescritos() {
        return medicamentosPrescritos;
    }

    public void setMedicamentosPrescritos(String medicamentosPrescritos) {
        this.medicamentosPrescritos = medicamentosPrescritos;
    }

    public String getInstruccionesAdicionales() {
        return instruccionesAdicionales;
    }

    public void setInstruccionesAdicionales(String instruccionesAdicionales) {
        this.instruccionesAdicionales = instruccionesAdicionales;
    }

   
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Receta)) {
            return false;
        }
        Receta other = (Receta) object;
        return this.id != null && this.id.equals(other.id);
    }

    @Override
    public String toString() {
        return "Receta{" +
                "id=" + id +
                ", paciente=" + paciente +
                ", medico=" + medico +
                ", fechaEmision='" + fechaEmision + '\'' +
                ", medicamentosPrescritos=" + medicamentosPrescritos +
                ", instruccionesAdicionales='" + instruccionesAdicionales + '\'' +
                '}';
    }
}
