/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



  public class Session {
   private static Usuario currentUser;
    private static EntityManagerFactory emf;
    private static ThreadLocal<EntityManager> em = new ThreadLocal<>();

    static {
        try {
            emf = Persistence.createEntityManagerFactory("HospitalPU");
            System.out.println("EntityManagerFactory inicializado correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setCurrentUser(Usuario user) {
        currentUser = user;
    }

    public static Usuario getCurrentUser() {
        return currentUser;
    }

    public static EntityManager getEntityManager() {
        if (em.get() == null) {
            em.set(emf.createEntityManager());
        }
        return em.get(); 
    }

    public static void close() {
        EntityManager entityManager = em.get();
    if (entityManager != null) {
        if (entityManager.isOpen()) {
            entityManager.close();
        }
        em.remove(); 
    }
    currentUser = null; 
    }

    public static void closeEntityManagerFactory() {
        if (emf != null) {
            emf.close();
        }
    }
  }

