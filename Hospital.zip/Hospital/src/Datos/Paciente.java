/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TypedQuery;

/**
 *
 * @author PC
 */
@Entity
@Table(name = "pacientes", schema = "public")
@NamedQueries({
        @NamedQuery(name = "Paciente.findAll", query = "SELECT p FROM Paciente p"),
        @NamedQuery(name = "Paciente.findByNombre", query = "SELECT p FROM Paciente p WHERE p.nombreCompleto = :nombreCompleto")
})
public class Paciente implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "nombre_completo", nullable = false)
    private String nombreCompleto;

    @Column(name = "fecha_nacimiento", nullable = false)
    private Date fechaNacimiento; // Cambiado de String a Date

    @Column(name = "sexo", nullable = false)
    private String sexo;

    @Column(name = "nacionalidad")
    private String nacionalidad;

    @Column(name = "numero_identificacion", unique = true, nullable = false)
    private String numeroIdentificacion;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "telefono")
    private String telefono;

    @Column(name = "correo_electronico")
    private String correoElectronico;

    @Column(name = "alergias")
    private String alergias;

    @Column(name = "historial_medico")
    private String historialMedico;

    @Column(name = "grupo_sanguineo")
    private String grupoSanguineo;

    @Column(name = "peso")
    private Integer peso;

    @Column(name = "estatura")
    private Long estatura;

    @OneToMany(mappedBy = "paciente")
    private List<Receta> recetas;

    // Constructor vacío
    public Paciente() {
    }

    // Constructor completo
    public Paciente(Long id, String nombreCompleto, Date fechaNacimiento, String sexo, String nacionalidad,
            String numeroIdentificacion, String direccion, String telefono, String correoElectronico,
            String alergias, String historialMedico, String grupoSanguineo, Integer peso, Long estatura) {
        this.id = id;
        this.nombreCompleto = nombreCompleto;
        this.fechaNacimiento = fechaNacimiento; // Cambiado a Date
        this.sexo = sexo;
        this.nacionalidad = nacionalidad;
        this.numeroIdentificacion = numeroIdentificacion;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.alergias = alergias;
        this.historialMedico = historialMedico;
        this.grupoSanguineo = grupoSanguineo;
        this.peso = peso;
        this.estatura = estatura;
    }

    // Métodos estáticos para consultas
    public static List<Paciente> findAll(EntityManager em) {
        TypedQuery<Paciente> query = em.createNamedQuery("Paciente.findAll", Paciente.class);
        return query.getResultList();
    }

    public static Paciente findByNombre(EntityManager em, String nombreCompleto) {
        TypedQuery<Paciente> query = em.createNamedQuery("Paciente.findByNombre", Paciente.class);
        query.setParameter("nombreCompleto", nombreCompleto);
        return query.getSingleResult();
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public Date getFechaNacimiento() { // Cambiado a Date
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) { // Cambiado a Date
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    public String getHistorialMedico() {
        return historialMedico;
    }

    public void setHistorialMedico(String historialMedico) {
        this.historialMedico = historialMedico;
    }

    public String getGrupoSanguineo() {
        return grupoSanguineo;
    }

    public void setGrupoSanguineo(String grupoSanguineo) {
        this.grupoSanguineo = grupoSanguineo;
    }

    public void setPeso(Integer peso) {
        this.peso = peso;
    }

    public void setEstatura(Long estatura) {
        this.estatura = estatura;
    }

    public Integer getPeso() {
        return peso;
    }

    public Long getEstatura() {
        return estatura;
    }

    public List<Receta> getRecetas() {
        return recetas;
    }

    public void setRecetas(List<Receta> recetas) {
        this.recetas = recetas;
    }

    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Paciente paciente = (Paciente) o;
        return Objects.equals(id, paciente.id) &&
                Objects.equals(nombreCompleto, paciente.nombreCompleto) &&
                Objects.equals(fechaNacimiento, paciente.fechaNacimiento) &&
                Objects.equals(sexo, paciente.sexo) &&
                Objects.equals(nacionalidad, paciente.nacionalidad) &&
                Objects.equals(numeroIdentificacion, paciente.numeroIdentificacion) &&
                Objects.equals(direccion, paciente.direccion) &&
                Objects.equals(telefono, paciente.telefono) &&
                Objects.equals(correoElectronico, paciente.correoElectronico) &&
                Objects.equals(alergias, paciente.alergias) &&
                Objects.equals(historialMedico, paciente.historialMedico) &&
                Objects.equals(grupoSanguineo, paciente.grupoSanguineo) &&
                Objects.equals(peso, paciente.peso) &&
                Objects.equals(estatura, paciente.estatura);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nombreCompleto, fechaNacimiento, sexo, nacionalidad, numeroIdentificacion, direccion,
                telefono, correoElectronico, alergias, historialMedico, grupoSanguineo, peso, estatura);
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "id=" + id +
                ", nombreCompleto='" + nombreCompleto + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                ", sexo='" + sexo + '\'' +
                ", nacionalidad='" + nacionalidad + '\'' +
                ", numeroIdentificacion='" + numeroIdentificacion + '\'' +
                ", direccion='" + direccion + '\'' +
                ", telefono='" + telefono + '\'' +
                ", correoElectronico='" + correoElectronico + '\'' +
                ", alergias='" + alergias + '\'' +
                ", historialMedico='" + historialMedico + '\'' +
                ", grupoSanguineo='" + grupoSanguineo + '\'' +
                ", peso=" + peso +
                ", estatura=" + estatura +
                ", recetas=" + recetas +
                '}';
    }
}
