/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Datos;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class RolTest {
    private static EntityManagerFactory emf;
    private EntityManager em;

    public RolTest() {
    }

    @BeforeClass
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory("HospitalPU");
    }

    @AfterClass
    public static void tearDownClass() {
        if (emf != null) {
            emf.close();
        }
    }

    @Before
    public void setUp() {
        em = emf.createEntityManager();
        em.getTransaction().begin();       
        em.getTransaction().commit();
    }

    @After
    public void tearDown() {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }

    @Test
    public void testFindAll() {
        System.out.println("findAll");
        List<Rol> result = Rol.findAll(em);
        assertEquals(2, result.size()); 
    }

    @Test
    public void testFindByNombre() {
        System.out.println("findByNombre");
        String nombre = "medico";
        Rol result = Rol.findByNombre(em, nombre);
        assertEquals("medico", result.getNombre());
    }

    @Test
    public void testToString() {
        System.out.println("toString");
        Rol rol = new Rol(1L, "medico");
        String expected = "Rol{id=1, nombre='medico'}";
        assertEquals(expected, rol.toString()); 
    }

    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Rol rol = new Rol();
        rol.setNombre("medico");
        assertEquals("medico", rol.getNombre()); 
    }
}