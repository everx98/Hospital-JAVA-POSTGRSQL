/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Datos;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author PC
 */
public class SessionTest {
    private Usuario user;

    @Before
    public void setUp() {
        user = new Usuario();
        user.setId(1L);
        user.setNumeroControl("21010217");
        user.setNombre("Everardo Ruiz Morales");
        Session.setCurrentUser(user); 
    }

    @After
    public void tearDown() {
        Session.setCurrentUser(null); 
        Session.close(); 
    }

    @AfterClass
    public static void tearDownClass() {
        Session.closeEntityManagerFactory();
    }

    @Test
    public void testSetCurrentUser() {
        Session.setCurrentUser(user);
        assertEquals(user, Session.getCurrentUser());
    }

    @Test
    public void testGetCurrentUser() {
        Usuario result = Session.getCurrentUser();
        assertNotNull(result);
        assertEquals(user, result);
    }

    @Test
    public void testGetEntityManager() {
        EntityManager result = Session.getEntityManager();
        assertNotNull(result);
        assertTrue(result.isOpen());
    }

    @Test
    public void testClose() {
    Session.setCurrentUser(user);
    assertNotNull(Session.getCurrentUser());   
    Session.close();  
    assertNull(Session.getCurrentUser());
    assertTrue(Session.getEntityManager().isOpen()); 
    }
}
