/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Datos;

import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class RecetaTest {
    
     private static EntityManagerFactory emf;
    private EntityManager em;

    @BeforeClass
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory("HospitalPU");
    }

    @AfterClass
    public static void tearDownClass() {
        if (emf != null) {
            emf.close();
        }
    }

    @Before
    public void setUp() {
        em = emf.createEntityManager();
    }

    @After
    public void tearDown() {
        if (em != null) {
            em.close();
        }
    }

    @Test
    public void testFindAll() {
        System.out.println("findAll");
        List<Receta> result = Receta.findAll(em);
        assertNotNull(result);
        assertTrue(result.size() > 0); // Aseguramos que haya recetas en la base de datos
    }

    @Test
    public void testFindByPaciente() {
        System.out.println("findByPaciente");
        Long pacienteId = 12456L; // Cambia este valor por uno válido en tu base de datos
        List<Receta> result = Receta.findByPaciente(em, pacienteId);
        assertNotNull(result);
        assertTrue(result.size() > 0); // Verifica que haya recetas para este paciente
    }

    @Test
    public void testGetId() {
        System.out.println("getId");
        Receta instance = new Receta();
        Long expResult = 1L; // Cambia según el ID que quieras probar
        instance.setId(expResult);
        Long result = instance.getId();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetId() {
        System.out.println("setId");
        Long id = 1L; // Define un valor válido de ID
        Receta instance = new Receta();
        instance.setId(id);
        assertEquals(id, instance.getId());
    }

    @Test
    public void testGetPaciente() {
        System.out.println("getPaciente");
        Receta instance = new Receta();
        Paciente expResult = new Paciente(); // Define un paciente válido
        instance.setPaciente(expResult);
        Paciente result = instance.getPaciente();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetPaciente() {
        System.out.println("setPaciente");
        Paciente paciente = new Paciente(); // Define un paciente válido
        Receta instance = new Receta();
        instance.setPaciente(paciente);
        assertEquals(paciente, instance.getPaciente());
    }

    @Test
    public void testGetMedico() {
        System.out.println("getMedico");
        Receta instance = new Receta();
        Medico expResult = new Medico(); // Define un médico válido
        instance.setMedico(expResult);
        Medico result = instance.getMedico();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetMedico() {
        System.out.println("setMedico");
        Medico medico = new Medico(); // Define un médico válido
        Receta instance = new Receta();
        instance.setMedico(medico);
        assertEquals(medico, instance.getMedico());
    }

    @Test
    public void testGetFechaEmision() {
        System.out.println("getFechaEmision");
        Receta instance = new Receta();
        Date expResult = new Date(); // Define una fecha válida
        instance.setFechaEmision(expResult);
        Date result = instance.getFechaEmision();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetFechaEmision() {
        System.out.println("setFechaEmision");
        Date fechaEmision = new Date(); // Define una fecha válida
        Receta instance = new Receta();
        instance.setFechaEmision(fechaEmision);
        assertEquals(fechaEmision, instance.getFechaEmision());
    }

    @Test
    public void testGetMedicamentosPrescritos() {
        System.out.println("getMedicamentosPrescritos");
        Receta instance = new Receta();
        String expResult = "Paracetamol"; // Define un medicamento válido
        instance.setMedicamentosPrescritos(expResult);
        String result = instance.getMedicamentosPrescritos();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetMedicamentosPrescritos() {
        System.out.println("setMedicamentosPrescritos");
        String medicamentosPrescritos = "Ibuprofeno"; // Define un medicamento válido
        Receta instance = new Receta();
        instance.setMedicamentosPrescritos(medicamentosPrescritos);
        assertEquals(medicamentosPrescritos, instance.getMedicamentosPrescritos());
    }

    @Test
    public void testGetInstruccionesAdicionales() {
        System.out.println("getInstruccionesAdicionales");
        Receta instance = new Receta();
        String expResult = "Tomar cada 8 horas"; 
        instance.setInstruccionesAdicionales(expResult);
        String result = instance.getInstruccionesAdicionales();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetInstruccionesAdicionales() {
        System.out.println("setInstruccionesAdicionales");
        String instruccionesAdicionales = "Tomar con alimentos"; 
        Receta instance = new Receta();
        instance.setInstruccionesAdicionales(instruccionesAdicionales);
        assertEquals(instruccionesAdicionales, instance.getInstruccionesAdicionales());
    }

    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        Receta instance = new Receta();
        int result = instance.hashCode();
        assertNotNull(result); 
    }

    @Test
    public void testEquals() {
        System.out.println("equals");
        Receta instance = new Receta();
        Receta other = new Receta();
        boolean result = instance.equals(other);
        assertFalse(result); 
    }

    @Test
    public void testToString() {
        System.out.println("toString");
        Receta instance = new Receta();
        String result = instance.toString();
        assertNotNull(result); 
    }
}