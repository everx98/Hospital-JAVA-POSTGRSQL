/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Datos;

import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author PC
 */
public class PacienteTest {
    
     private static EntityManagerFactory emf;
    private EntityManager em;
    private Paciente instance;

    @BeforeClass
    public static void setUpClass() {
      
        emf = Persistence.createEntityManagerFactory("HospitalPU");
    }

    @AfterClass
    public static void tearDownClass() {
       
        emf.close();
    }

    @Before
    public void setUp() {
     
        em = emf.createEntityManager();
        instance = new Paciente(); 
    }

    @After
    public void tearDown() {
       
        if (em.isOpen()) {
            em.close();
        }
    }

    @Test
    public void testFindAll() {
        System.out.println("findAll");
       
        List<Paciente> result = Paciente.findAll(em);
        assertNotNull(result); 
        assertTrue(result.size() >= 0); 
    }

    @Test
    public void testFindByNombre() {
        System.out.println("findByNombre");
        String nombreCompleto = "Lucia Morales";
        Paciente result = Paciente.findByNombre(em, nombreCompleto);
        assertNotNull(result); 
        assertEquals(nombreCompleto, result.getNombreCompleto()); 
    }
    
    @Test
    public void testGetId() {
        System.out.println("getId");
        Long id = 1L;
        instance.setId(id);
        assertEquals(id, instance.getId()); 
    }

    @Test
    public void testSetId() {
        System.out.println("setId");
        Long id = 1L;
        instance.setId(id);
        assertEquals(id, instance.getId()); 
    }

    
   @Test
    public void testGetNombreCompleto() {
        System.out.println("getNombreCompleto");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getNombreCompleto();
        assertEquals(expResult, result);
    }

    
    @Test
    public void testSetNombreCompleto() {
        System.out.println("setNombreCompleto");
        String nombreCompleto = "Lucia Morales"; 
        Paciente instance = new Paciente();
        instance.setNombreCompleto(nombreCompleto);
        assertEquals(nombreCompleto, instance.getNombreCompleto());
    }

    
    @Test
    public void testGetFechaNacimiento() {
        System.out.println("getFechaNacimiento");
        Paciente instance = new Paciente();
        Date expResult = null;
        Date result = instance.getFechaNacimiento();
        assertEquals(expResult, result);
    }

   
    @Test
    public void testSetFechaNacimiento() {
        System.out.println("setFechaNacimiento");
        Date fechaNacimiento = new Date(1998-05-12); 
        Paciente instance = new Paciente();
        instance.setFechaNacimiento(fechaNacimiento);
        assertEquals(fechaNacimiento, instance.getFechaNacimiento());
    }

    
    @Test
    public void testGetSexo() {
        System.out.println("getSexo");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getSexo();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetSexo() {
        System.out.println("setSexo");
        String sexo = "Femenino"; 
        Paciente instance = new Paciente();
        instance.setSexo(sexo);
        assertEquals(sexo, instance.getSexo());
    }

   
    @Test
    public void testGetNacionalidad() {
        System.out.println("getNacionalidad");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getNacionalidad();
        assertEquals(expResult, result);
    }

    /**
     * Test of setNacionalidad method, of class Paciente.
     */
    @Test
    public void testSetNacionalidad() {
        System.out.println("setNacionalidad");
        String nacionalidad = "Mexicana"; 
        Paciente instance = new Paciente();
        instance.setNacionalidad(nacionalidad);
        assertEquals(nacionalidad, instance.getNacionalidad());
    }

    /**
     * Test of getNumeroIdentificacion method, of class Paciente.
     */
    @Test
    public void testGetNumeroIdentificacion() {
        System.out.println("getNumeroIdentificacion");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getNumeroIdentificacion();
        assertEquals(expResult, result);
    }

    /**
     * Test of setNumeroIdentificacion method, of class Paciente.
     */
    @Test
    public void testSetNumeroIdentificacion() {
        System.out.println("setNumeroIdentificacion");
        String numeroIdentificacion = "LUCI87GHXZ"; 
        Paciente instance = new Paciente();
        instance.setNumeroIdentificacion(numeroIdentificacion);
        assertEquals(numeroIdentificacion, instance.getNumeroIdentificacion());
    }

    /**
     * Test of getDireccion method, of class Paciente.
     */
    @Test
    public void testGetDireccion() {
        System.out.println("getDireccion");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getDireccion();
        assertEquals(expResult, result);
    }

    /**
     * Test of setDireccion method, of class Paciente.
     */
    @Test
    public void testSetDireccion() {
        System.out.println("setDireccion");
        String direccion = "palmira";
        Paciente instance = new Paciente();
        instance.setDireccion(direccion);
        assertEquals(direccion, instance.getDireccion());
    }

    /**
     * Test of getTelefono method, of class Paciente.
     */
    @Test
    public void testGetTelefono() {
        System.out.println("getTelefono");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getTelefono();
        assertEquals(expResult, result);
    }

    /**
     * Test of setTelefono method, of class Paciente.
     */
    @Test
    public void testSetTelefono() {
        System.out.println("setTelefono");
        String telefono = "2741234568"; 
        Paciente instance = new Paciente();
        instance.setTelefono(telefono);
        assertEquals(telefono, instance.getTelefono());
    }

    /**
     * Test of getCorreoElectronico method, of class Paciente.
     */
    @Test
    public void testGetCorreoElectronico() {
        System.out.println("getCorreoElectronico");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getCorreoElectronico();
        assertEquals(expResult, result);
    }

    /**
     * Test of setCorreoElectronico method, of class Paciente.
     */
    @Test
    public void testSetCorreoElectronico() {
        System.out.println("setCorreoElectronico");
        String correoElectronico = "luci@gmail.com"; 
        Paciente instance = new Paciente();
        instance.setCorreoElectronico(correoElectronico);
        assertEquals(correoElectronico, instance.getCorreoElectronico());
    }

    /**
     * Test of getAlergias method, of class Paciente.
     */
    @Test
    public void testGetAlergias() {
        System.out.println("getAlergias");
        Paciente instance = new Paciente();
        String expResult = null;
        String result = instance.getAlergias();
        assertEquals(expResult, result);
    }

    /**
     * Test of setAlergias method, of class Paciente.
     */
    @Test
    public void testSetAlergias() {
        System.out.println("setAlergias");
        String alergias = "paracetamol\n" +
"mariscos";
        Paciente instance = new Paciente();
        instance.setAlergias(alergias);
        assertEquals(alergias, instance.getAlergias());
    }

    /**
     * Test of getHistorialMedico method, of class Paciente.
     */
    @Test
    public void testGetHistorialMedico() {
        System.out.println("getHistorialMedico");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getHistorialMedico();
        assertEquals(expResult, result);
    }

    /**
     * Test of setHistorialMedico method, of class Paciente.
     */
    @Test
    public void testSetHistorialMedico() {
        System.out.println("setHistorialMedico");
        String historialMedico = "ninguna";
        Paciente instance = new Paciente();
        instance.setHistorialMedico(historialMedico);
        assertEquals(historialMedico, instance.getHistorialMedico());
    }

    /**
     * Test of getGrupoSanguineo method, of class Paciente.
     */
    @Test
    public void testGetGrupoSanguineo() {
        System.out.println("getGrupoSanguineo");
        Paciente instance = new Paciente();
        String expResult = null; 
        String result = instance.getGrupoSanguineo();
        assertEquals(expResult, result);
    }

    /**
     * Test of setGrupoSanguineo method, of class Paciente.
     */
    @Test
    public void testSetGrupoSanguineo() {
        System.out.println("setGrupoSanguineo");
        String grupoSanguineo = "O+";
        Paciente instance = new Paciente();
        instance.setGrupoSanguineo(grupoSanguineo);
        assertEquals(grupoSanguineo, instance.getGrupoSanguineo());
    }

    /**
     * Test of getPeso method, of class Paciente.
     */
    @Test
    public void testGetPeso() {
        System.out.println("getPeso");
        Paciente instance = new Paciente();
        Integer expResult = null; 
        Integer result = instance.getPeso();
        assertEquals(expResult, result);
    }

    /**
     * Test of setPeso method, of class Paciente.
     */
    @Test
    public void testSetPeso() {
        System.out.println("setPeso");
        Integer peso = 66; 
        Paciente instance = new Paciente();
        instance.setPeso(peso);
        assertEquals(peso, instance.getPeso());
    }
     @Test
   public void testGetEstatura() {
        System.out.println("getEstatura");
        Paciente instance = new Paciente();
        Long expResult = null; 
        Long result = instance.getEstatura();
        assertEquals(expResult, result); 
        Long expectedEstatura = 160L;
        instance.setEstatura(expectedEstatura);
        result = instance.getEstatura();
        assertEquals(expectedEstatura, result); 
    }

  
    @Test
    public void testSetEstatura() {
        System.out.println("setEstatura");
        Long estatura = 160L;
        Paciente instance = new Paciente();
        instance.setEstatura(estatura); 

    
        Long result = instance.getEstatura();
        assertEquals(estatura, result);
    }
    @Test
    public void testToString() {
      System.out.println("toString");
    instance.setId(1L); 
    instance.setNombreCompleto("Lucia Morales");
    instance.setFechaNacimiento(new Date(896771400000L)); 
    instance.setSexo("Femenino");
    instance.setNacionalidad("Mexicana");
    instance.setNumeroIdentificacion("LUCI87GHXZ");
    instance.setDireccion("Calle Falsa 123");
    instance.setTelefono("2741234568");
    instance.setCorreoElectronico("luci@gmail.com");
    instance.setAlergias("paracetamol\nmariscos");
    instance.setHistorialMedico("ninguna");
    instance.setGrupoSanguineo("O+");
    instance.setPeso(66);
    instance.setEstatura(160L); 
    instance.setRecetas(null);   
    String result = instance.toString();

   
    String expResult = "Paciente{id=1, nombreCompleto='Lucia Morales', fechaNacimiento=Tue Jun 02 02:10:00 CDT 1998, " +
                       "sexo='Femenino', nacionalidad='Mexicana', numeroIdentificacion='LUCI87GHXZ', " +
                       "direccion='Calle Falsa 123', telefono='2741234568', correoElectronico='luci@gmail.com', " +
                       "alergias='paracetamol\nmariscos', historialMedico='ninguna', grupoSanguineo='O+', " +
                       "peso=66, estatura=160, recetas=null}";

    assertEquals(expResult, result);
    }
    
}
