/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Datos;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author PC
 */
public class MedicoTest {
    private EntityManagerFactory emf;
    private EntityManager em;
     private Medico instance; 
    public MedicoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        emf = Persistence.createEntityManagerFactory("HospitalPU"); 
        em = emf.createEntityManager();
         instance = new Medico();
    }
    
    @After
    public void tearDown() {
        if (em != null) {
            em.close();
        }
        
    }

  @Test
    public void testGetId() {
        System.out.println("getId");
        Long expResult = null;
        Long result = instance.getId();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetId() {
        System.out.println("setId");
        Long id = 21010217L; 
        instance.setId(id);
        assertEquals(id, instance.getId()); 
    }

    @Test
    public void testGetNombreCompleto() {
        System.out.println("getNombreCompleto");
        String nombreCompleto = "Everardo Ruiz Morales"; 
        instance.setNombreCompleto(nombreCompleto); 
        String result = instance.getNombreCompleto();
        assertEquals(nombreCompleto, result); 
    }

    @Test
    public void testSetNombreCompleto() {
        System.out.println("setNombreCompleto");
        String nombreCompleto = "Everardo Ruiz Morales"; 
        instance.setNombreCompleto(nombreCompleto);
        assertEquals(nombreCompleto, instance.getNombreCompleto()); 
    }

    @Test
    public void testGetNumeroLicencia() {
        System.out.println("getNumeroLicencia");
        String numeroLicencia = "11233456"; 
        instance.setNumeroLicencia(numeroLicencia);
        String result = instance.getNumeroLicencia();
        assertEquals(numeroLicencia, result);
    }

    @Test
    public void testSetNumeroLicencia() {
        System.out.println("setNumeroLicencia");
        String numeroLicencia = "11233456"; 
        instance.setNumeroLicencia(numeroLicencia);
        assertEquals(numeroLicencia, instance.getNumeroLicencia()); 
    }

    @Test
    public void testGetEspecialidad() {
        System.out.println("getEspecialidad");
        String especialidad = "Medico"; 
        instance.setEspecialidad(especialidad);
        String result = instance.getEspecialidad();
        assertEquals(especialidad, result);
    }

    @Test
    public void testSetEspecialidad() {
        System.out.println("setEspecialidad");
        String especialidad = "Medico"; 
        instance.setEspecialidad(especialidad);
        assertEquals(especialidad, instance.getEspecialidad()); 
    }

    @Test
    public void testGetTelefono() {
        System.out.println("getTelefono");
        String telefono = "2741087978"; 
        instance.setTelefono(telefono);
        String result = instance.getTelefono();
        assertEquals(telefono, result);
    }

    @Test
    public void testSetTelefono() {
        System.out.println("setTelefono");
        String telefono = "2741087978"; 
        instance.setTelefono(telefono);
        assertEquals(telefono, instance.getTelefono()); 
    }

    @Test
    public void testGetCurp() {
        System.out.println("getCurp");
        String curp = "RUGE770512HVVZ321";
        instance.setCurp(curp);
        String result = instance.getCurp();
        assertEquals(curp, result);
    }

    @Test
    public void testSetCurp() {
        System.out.println("setCurp");
        String curp = "RUGE770512HVVZ321";
        instance.setCurp(curp);
        assertEquals(curp, instance.getCurp()); 
    }

    @Test
    public void testGetDireccionConsultorio() {
        System.out.println("getDireccionConsultorio");
        String direccionConsultorio = "F. Madero, Oriente 6"; 
        instance.setDireccionConsultorio(direccionConsultorio);
        String result = instance.getDireccionConsultorio();
        assertEquals(direccionConsultorio, result); 
    }

    @Test
    public void testSetDireccionConsultorio() {
        System.out.println("setDireccionConsultorio");
        String direccionConsultorio = "F. Madero, Oriente 6"; 
        instance.setDireccionConsultorio(direccionConsultorio);
        assertEquals(direccionConsultorio, instance.getDireccionConsultorio()); 
    }

    @Test
    public void testGetCorreoElectronico() {
        System.out.println("getCorreoElectronico");
        String correoElectronico = "everardoruiz@gmail.com"; 
        instance.setCorreoElectronico(correoElectronico);
        String result = instance.getCorreoElectronico();
        assertEquals(correoElectronico, result);
    }

    @Test
    public void testSetCorreoElectronico() {
        System.out.println("setCorreoElectronico");
        String correoElectronico = "everardoruiz@gmail.com"; 
        instance.setCorreoElectronico(correoElectronico);
        assertEquals(correoElectronico, instance.getCorreoElectronico()); 
    }

    @Test
    public void testGetUsuarioId() {
        System.out.println("getUsuarioId");
        Integer expResult = null;
        Integer result = instance.getUsuarioId();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetUsuarioId() {
        System.out.println("setUsuarioId");
        Integer usuarioId = 1; 
        instance.setUsuarioId(usuarioId);
        assertEquals(usuarioId, instance.getUsuarioId()); 
    }

    @Test
    public void testSetContraseña() {
        System.out.println("setContraseña");
        String contraseña = "Ev3r@rd0_98"; 
        instance.setContraseña(contraseña);
        assertEquals(contraseña, instance.getContraseña()); 
    }

    @Test
    public void testGetContraseña() {
        System.out.println("getContraseña");
        String contraseña = "Ev3r@rd0_98"; 
        instance.setContraseña(contraseña); 
        String result = instance.getContraseña();
        assertEquals(contraseña, result);
    }

    @Test
    public void testToString() {
        System.out.println("toString");
        String expected = "Medico{" +
                "id=null" +
                ", nombreCompleto='null'" +
                ", numeroLicencia='null'" +
                ", especialidad='null'" +
                ", telefono='null'" +
                ", curp='null'" +
                ", direccionConsultorio='null'" +
                ", correoElectronico='null'" +
                ", usuarioId=null" +
                ", contraseña='null'" +
                '}';
        String result = instance.toString();
        assertEquals(expected, result);
    }
}
