/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Datos;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author PC
 */
public class UsuarioTest {
 private EntityManagerFactory emf;
    private EntityManager em;

    public UsuarioTest() {
    }

    @Before
    public void setUp() {
       
        emf = Persistence.createEntityManagerFactory("HospitalPU"); 
        em = emf.createEntityManager();
    }

    @After
    public void tearDown() {
        
        if (em != null && em.isOpen()) {
            em.close();
        }
        if (emf != null) {
            emf.close();
        }
    }

    @Test
    public void testFindAll() {
        System.out.println("findAll");
        List<Usuario> result = Usuario.findAll(em);
        assertNotNull(result); 
        assertTrue(result.size() >= 0); 
    }

    @Test
    public void testFindByNumeroControl() {
        System.out.println("findByNumeroControl");
        String numeroControl = "21010217"; 
        Usuario result = Usuario.findByNumeroControl(em, numeroControl);
        assertNotNull(result); 
        assertEquals(numeroControl, result.getNumeroControl()); 
    }

    @Test
    public void testFindByRol() {
        System.out.println("findByRol");
        String rolNombre = "medico"; 
        List<Usuario> result = Usuario.findByRol(em, rolNombre);
        assertNotNull(result); 
        assertTrue(result.size() >= 0); 
    }

    @Test
    public void testGetId() {
        System.out.println("getId");
        Usuario instance = new Usuario();
        Long expResult = null; 
        Long result = instance.getId();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetId() {
        System.out.println("setId");
        Long id = 1L; 
        Usuario instance = new Usuario();
        instance.setId(id);
        assertEquals(id, instance.getId()); 
    }

    @Test
    public void testGetNumeroControl() {
        System.out.println("getNumeroControl");
        Usuario instance = new Usuario();
        String expResult = "21010217"; 
        instance.setNumeroControl(expResult);
        String result = instance.getNumeroControl();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetNumeroControl() {
        System.out.println("setNumeroControl");
        String numeroControl = "21010217"; 
        Usuario instance = new Usuario();
        instance.setNumeroControl(numeroControl);
        assertEquals(numeroControl, instance.getNumeroControl()); 
    }

    @Test
    public void testGetContraseña() {
        System.out.println("getContraseña");
        Usuario instance = new Usuario();
        String expResult = "Ev3r@rd0_98"; 
        instance.setContraseña(expResult); 
        String result = instance.getContraseña();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetContraseña() {
        System.out.println("setContraseña");
        String contraseña = "Ev3r@rd0_98"; 
        Usuario instance = new Usuario();
        instance.setContraseña(contraseña);
        assertEquals(contraseña, instance.getContraseña()); 
    }

    @Test
    public void testGetRol() {
        System.out.println("getRol");
    Rol rol = new Rol();
    rol.setId(1L);
    rol.setNombre("medico");

    Usuario instance = new Usuario();
    instance.setRol(rol); 

    Rol result = instance.getRol(); 
    assertEquals(rol, result);
    }

    @Test
    public void testSetRol() {
        System.out.println("setRol");
        Rol rol = new Rol(); 
        rol.setNombre("medico"); 
        Usuario instance = new Usuario();
        instance.setRol(rol);
        assertEquals(rol, instance.getRol()); 
    }

    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Usuario instance = new Usuario();
        String expResult = "Everardo Ruiz Morales"; 
        instance.setNombre(expResult); 
        String result = instance.getNombre();
        assertEquals(expResult, result);
    }

    @Test
    public void testSetNombre() {
        System.out.println("setNombre");
        String nombre = "Everardo Ruiz Morales"; 
        Usuario instance = new Usuario();
        instance.setNombre(nombre);
        assertEquals(nombre, instance.getNombre());
    }

    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        Usuario instance = new Usuario();
        int expResult = 0; 
        int result = instance.hashCode();
        assertEquals(expResult, result);
    }

    @Test
    public void testEquals() {
      System.out.println("equals");
    
    Usuario usuario1 = new Usuario();
    usuario1.setId(1L);
    usuario1.setNumeroControl("21010217");
    usuario1.setNombre("Everardo Ruiz Morales");
    Rol rol = new Rol();
    rol.setNombre("medico");
    usuario1.setRol(rol);

    Usuario usuario2 = new Usuario();
    usuario2.setId(1L);
    usuario2.setNumeroControl("21010217");
    usuario2.setNombre("Everardo Ruiz Morales");
    usuario2.setRol(rol);

    boolean expResult = true; 
    boolean result = usuario1.equals(usuario2);
    assertEquals(expResult, result);
}
    @Test
    public void testToString() {
       System.out.println("toString");
    
    Usuario instance = new Usuario();
    instance.setId(1L); 
    instance.setNumeroControl("21010217"); 
    instance.setNombre("Everardo Ruiz Morales"); 
    String expResult = "Usuario{id=1, numeroControl='21010217', nombre='Everardo Ruiz Morales', rol=null}";
    
    String result = instance.toString();
    assertEquals(expResult, result);
    }
}